"""
Run this script once to set admin accounts.
Usage: python make_admin.py
"""
import os
os.environ['MONGO_URI'] = 'mongodb+srv://tradersvault:TraderVault2025!@tradersvault.8qpmmyn.mongodb.net/tradersvault?retryWrites=true&w=majority&appName=tradersvault'
os.environ['MONGO_DB_NAME'] = 'tradersvault'

from database import get_db
db = get_db()

admins = [
    'yekhaungpaing03@gmail.com',
    'junqi494@gmail.com',
    'khooningxuan@gmail.com',
]

for email in admins:
    result = db.users.update_one(
        {'email': email},
        {'$set': {'role': 'admin', 'plan': 'high'}}
    )
    if result.matched_count > 0:
        print(f'✓ {email} — set as admin with Elite plan')
    else:
        print(f'✗ {email} — user not found (they need to register first)')

print('\nDone. Log out and back in to see the Admin panel.')