"""
Journex - Email Module
"""

import os
import requests
from flask import url_for

SITE_URL = 'https://journex-production.up.railway.app'


def send_email(to_email, subject, html_content):
    """Send email via Resend REST API."""
    api_key   = 're_N5qv58qi_KLFeV9D5HjbNGDsePy6Ybznk'
    mail_from = os.environ.get('MAIL_FROM', 'onboarding@resend.dev')

    print(f"[Email] Sending to: {to_email} subject: {subject}")

    try:
        response = requests.post(
            'https://api.resend.com/emails',
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type':  'application/json',
            },
            json={
                'from':    mail_from,
                'to':      [to_email],
                'subject': subject,
                'html':    html_content,
            },
            timeout=10
        )
        if response.status_code in (200, 201):
            print(f"[Email] Sent successfully to {to_email}")
            return True
        else:
            print(f"[Email] Failed {response.status_code}: {response.text}")
            return False
    except Exception as e:
        print(f"[Email] Error: {e}")
        return False


def _base_template(content):
    return f"""<!DOCTYPE html>
<html>
<body style="background:#080c14;color:#f1f5f9;font-family:monospace;padding:40px;margin:0;">
  <div style="max-width:520px;margin:0 auto;background:#0f1623;border:1px solid rgba(255,255,255,0.07);border-radius:16px;padding:40px;">
    <div style="font-size:1.2rem;font-weight:800;letter-spacing:0.08em;margin-bottom:24px;">
      <span style="color:#3b82f6;">◈</span> TRADERS<span style="color:#3b82f6;">VAULT</span>
    </div>
    {content}
    <p style="color:#64748b;font-size:0.75rem;margin-top:32px;border-top:1px solid rgba(255,255,255,0.07);padding-top:16px;">
      Journex · Your professional trading journal · Not financial advice
    </p>
  </div>
</body>
</html>"""


def send_verification_email(user_email, username, token):
    try:
        verify_url = url_for('auth.verify_email', token=token, _external=True)
    except:
        verify_url = f'{SITE_URL}/auth/verify/{token}'
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">Verify your email</h2>
    <p style="color:#94a3b8;margin-bottom:24px;">Hi {username}, click below to verify your account.</p>
    <a href="{verify_url}" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;">
      Verify Email
    </a>
    <p style="color:#64748b;font-size:0.8rem;margin-top:20px;">Link expires in 24 hours.</p>
    """
    return send_email(user_email, "Verify your Journex account", _base_template(content))



def send_welcome_email(user_email, username):
    """Send a welcome email after successful registration."""
    content = f"""
    <h2 style="font-size:1.4rem;margin:0 0 6px;">Welcome to Journex, {username}! 🎉</h2>
    <p style="color:#94a3b8;margin-bottom:20px;">Your account is set up and ready to go. Here's what you can do right now:</p>

    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px;">
      <div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:8px;padding:14px;">
        <div style="font-weight:700;color:#818cf8;margin-bottom:4px;">📒 Log Your First Trade</div>
        <div style="font-size:0.85rem;color:#94a3b8;">Open your journal and record your first trade. Add entry, SL, TP, chart screenshot and notes.</div>
      </div>
      <div style="background:rgba(6,182,212,0.08);border:1px solid rgba(6,182,212,0.2);border-radius:8px;padding:14px;">
        <div style="font-weight:700;color:#06b6d4;margin-bottom:4px;">📊 Track Your Analytics</div>
        <div style="font-size:0.85rem;color:#94a3b8;">After a few trades, visit your Analytics page to see win rate, R:R ratio, best pairs and more.</div>
      </div>
      <div style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.2);border-radius:8px;padding:14px;">
        <div style="font-weight:700;color:#22c55e;margin-bottom:4px;">🔔 Set Price Alerts</div>
        <div style="font-size:0.85rem;color:#94a3b8;">Get instant email notifications when EUR/USD, XAU/USD, BTC/USD or any pair hits your target price.</div>
      </div>
      <div style="background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:8px;padding:14px;">
        <div style="font-weight:700;color:#f59e0b;margin-bottom:4px;">📈 View Live Charts</div>
        <div style="font-size:0.85rem;color:#94a3b8;">Built-in TradingView-style charts for 15+ pairs. M1 to W1 timeframes, all inside Journex.</div>
      </div>
    </div>

    <a href="{SITE_URL}/journal" style="display:block;text-align:center;background:linear-gradient(135deg,#6366f1,#06b6d4);color:#fff;text-decoration:none;padding:14px 24px;border-radius:8px;font-weight:700;font-size:14px;margin-bottom:16px;">
      Open Your Journal →
    </a>

    <p style="font-size:0.8rem;color:#475569;text-align:center;">
      Start on the Free plan — upgrade to Pro or Elite anytime for unlimited trades and AI analysis.
    </p>
    """
    return send_email(user_email, f'Welcome to Journex, {username}! 🎉', _base_template(content))

def send_password_reset_email(user_email, username, token):
    try:
        reset_url = url_for('auth.reset_password', token=token, _external=True)
    except:
        reset_url = f'{SITE_URL}/auth/reset-password/{token}'
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">Reset your password</h2>
    <p style="color:#94a3b8;margin-bottom:24px;">Hi {username}, click below to reset your password.</p>
    <a href="{reset_url}" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;">
      Reset Password
    </a>
    <p style="color:#64748b;font-size:0.8rem;margin-top:20px;">Link expires in 1 hour.</p>
    """
    return send_email(user_email, "Reset your Journex password", _base_template(content))


def send_payment_receipt_email(user_email, username, plan_name, amount):
    try:
        journal_url = url_for('journal.index', _external=True)
    except:
        journal_url = f'{SITE_URL}/journal'
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">Payment confirmed</h2>
    <p style="color:#94a3b8;margin-bottom:24px;">Hi {username}, your payment was successful.</p>
    <div style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.2);border-radius:10px;padding:20px;margin-bottom:24px;">
      <div style="font-weight:700;margin-top:4px;">{plan_name} — ${amount}/month</div>
    </div>
    <a href="{journal_url}" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;">
      Open Journal
    </a>
    """
    return send_email(user_email, f"Payment confirmed — {plan_name}", _base_template(content))


def send_alert_email(to_email, username, pair, price, target, condition, message=''):
    """Send price alert triggered email."""
    direction = 'above' if condition == 'above' else 'below'
    arrow     = '↑' if condition == 'above' else '↓'
    color     = '#22c55e' if condition == 'above' else '#ef4444'

    msg_block = f"""
    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:14px;margin-bottom:20px;">
      <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Your Note</div>
      <div style="font-size:0.9rem;color:#94a3b8;line-height:1.6;">{message}</div>
    </div>
    """ if message else ''

    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">{arrow} Price Alert Triggered!</h2>
    <p style="color:#94a3b8;margin-bottom:20px;">Hi {username}, your price alert has been triggered.</p>

    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:20px;margin-bottom:20px;text-align:center;">
      <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">Pair</div>
      <div style="font-size:1.4rem;font-weight:800;color:#818cf8;margin-bottom:14px;">{pair}</div>
      <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">Current Price</div>
      <div style="font-size:2rem;font-weight:800;color:{color};">{price:.5f}</div>
      <div style="margin-top:10px;font-size:0.85rem;color:#94a3b8;">
        went <strong style="color:{color};">{direction}</strong> your target of
        <strong style="color:{color};">{target}</strong>
      </div>
    </div>

    {msg_block}

    <a href="{SITE_URL}/charts" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:700;">
      View Live Charts →
    </a>
    """
    return send_email(to_email, f'🔔 Alert: {pair} went {direction} {target}', _base_template(content))


def send_consecutive_loss_email(to_email, username, loss_count, pair, daily_pl):
    """Alert user after consecutive losses."""
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">🔴 {loss_count} Consecutive Losses Today</h2>
    <p style="color:#94a3b8;margin-bottom:20px;">Hi {username}, you've had {loss_count} losses in a row today.</p>
    <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:20px;margin-bottom:20px;text-align:center;">
      <div style="font-size:2rem;font-weight:800;color:#ef4444;">-${abs(daily_pl)}</div>
      <div style="font-size:0.85rem;color:#94a3b8;margin-top:6px;">total loss today · last pair: {pair}</div>
    </div>
    <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;margin-bottom:20px;">
      <div style="font-size:0.9rem;font-weight:700;color:#e2e8f0;margin-bottom:8px;">💡 Consider these steps:</div>
      <ul style="color:#94a3b8;font-size:0.85rem;line-height:1.8;margin:0;padding-left:20px;">
        <li>Step away from the screen for 30 minutes</li>
        <li>Review what went wrong on each trade</li>
        <li>Check if you're deviating from your plan</li>
        <li>Consider reducing position size on next trade</li>
      </ul>
    </div>
    <a href="{SITE_URL}/journal" style="display:block;text-align:center;background:#3b82f6;color:#fff;text-decoration:none;padding:12px 24px;border-radius:8px;font-weight:700;">Review Your Trades →</a>
    """
    return send_email(to_email, f'🔴 {loss_count} consecutive losses today — take a break', _base_template(content))


def send_daily_loss_limit_email(to_email, username, daily_pl, limit):
    """Alert user when daily loss limit is hit."""
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">🚨 Daily Loss Limit Reached</h2>
    <p style="color:#94a3b8;margin-bottom:20px;">Hi {username}, you've hit your daily loss limit.</p>
    <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:20px;margin-bottom:20px;text-align:center;">
      <div style="font-size:2rem;font-weight:800;color:#ef4444;">-${abs(daily_pl)}</div>
      <div style="font-size:0.85rem;color:#94a3b8;margin-top:6px;">today's loss · your limit: ${limit}</div>
    </div>
    <p style="color:#94a3b8;font-size:0.9rem;">Your daily loss limit of <strong style="color:#e2e8f0;">${limit}</strong> has been reached. We strongly recommend stopping trading for today to protect your capital.</p>
    <a href="{SITE_URL}/risk" style="display:block;text-align:center;background:#3b82f6;color:#fff;text-decoration:none;padding:12px 24px;border-radius:8px;font-weight:700;margin-top:20px;">View Risk Manager →</a>
    """
    return send_email(to_email, f'🚨 Daily loss limit hit — stop trading today', _base_template(content))


def send_weekly_performance_email(to_email, username, stats):
    """Weekly performance summary email sent every Monday."""
    pl_color = '#22c55e' if stats.get('week_pl', 0) >= 0 else '#ef4444'
    content = f"""
    <h2 style="font-size:1.3rem;margin:0 0 8px;">📊 Your Weekly Performance Report</h2>
    <p style="color:#94a3b8;margin-bottom:20px;">Hi {username}, here's how you traded last week.</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">
      <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;text-align:center;">
        <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Week P&L</div>
        <div style="font-size:1.8rem;font-weight:800;color:{pl_color};">{"+" if stats.get("week_pl",0) >= 0 else ""}${stats.get("week_pl",0)}</div>
      </div>
      <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;text-align:center;">
        <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Win Rate</div>
        <div style="font-size:1.8rem;font-weight:800;color:#818cf8;">{stats.get("win_rate",0)}%</div>
      </div>
      <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;text-align:center;">
        <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Total Trades</div>
        <div style="font-size:1.8rem;font-weight:800;color:#e2e8f0;">{stats.get("total_trades",0)}</div>
      </div>
      <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;text-align:center;">
        <div style="font-size:0.75rem;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Avg R:R</div>
        <div style="font-size:1.8rem;font-weight:800;color:#06b6d4;">{stats.get("avg_rr",0)}R</div>
      </div>
    </div>
    <div style="background:#0f1128;border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:16px;margin-bottom:20px;">
      <div style="font-size:0.85rem;color:#94a3b8;line-height:1.7;">
        <strong style="color:#e2e8f0;">Best pair:</strong> {stats.get("best_pair","N/A")} &nbsp;|&nbsp;
        <strong style="color:#e2e8f0;">Best session:</strong> {stats.get("best_session","N/A")} &nbsp;|&nbsp;
        <strong style="color:#e2e8f0;">Wins:</strong> {stats.get("wins",0)} &nbsp;|&nbsp;
        <strong style="color:#e2e8f0;">Losses:</strong> {stats.get("losses",0)}
      </div>
    </div>
    <a href="{SITE_URL}/analytics" style="display:block;text-align:center;background:#3b82f6;color:#fff;text-decoration:none;padding:12px 24px;border-radius:8px;font-weight:700;">View Full Analytics →</a>
    """
    return send_email(to_email, f'📊 Your weekly trading report — {stats.get("week_pl",0):+}', _base_template(content))
