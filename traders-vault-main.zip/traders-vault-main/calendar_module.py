"""
Traders Vault - Trade Calendar Module
========================================
Shows trades on a calendar with daily P&L.
Available for Pro and Elite plans.
"""

from flask import Blueprint, render_template, session, jsonify, redirect, url_for, flash
from database import get_trades
from auth import login_required, get_current_user
from datetime import datetime, date
import calendar

calendar_bp = Blueprint('calendar', __name__)


def get_calendar_data(user_id, year, month):
    """Build calendar data for a given month."""
    all_trades = get_trades(user_id)

    # Filter trades for this month
    day_map = {}
    for t in all_trades:
        td = t.get('trade_date', '')
        if not td:
            continue
        try:
            d = datetime.strptime(td, '%Y-%m-%d')
            if d.year == year and d.month == month:
                day = d.day
                if day not in day_map:
                    day_map[day] = {
                        'trades': 0,
                        'pl':     0.0,
                        'wins':   0,
                        'losses': 0,
                    }
                day_map[day]['trades'] += 1
                pl = t.get('profit_loss')
                if pl is not None:
                    day_map[day]['pl'] += pl
                    if pl > 0:
                        day_map[day]['wins'] += 1
                    elif pl < 0:
                        day_map[day]['losses'] += 1
        except Exception:
            continue

    # Round P&L values
    for day in day_map:
        day_map[day]['pl'] = round(day_map[day]['pl'], 2)

    # Build weekly summary
    cal      = calendar.monthcalendar(year, month)
    weeks    = []
    for week in cal:
        week_pl     = 0.0
        week_trades = 0
        week_days   = 0
        for day in week:
            if day != 0 and day in day_map:
                week_pl     += day_map[day]['pl']
                week_trades += day_map[day]['trades']
                week_days   += 1
        weeks.append({
            'pl':     round(week_pl, 2),
            'trades': week_trades,
            'days':   week_days,
        })

    # Monthly totals
    total_pl     = round(sum(d['pl']     for d in day_map.values()), 2)
    total_trades = sum(d['trades'] for d in day_map.values())
    trading_days = len(day_map)

    return {
        'day_map':     day_map,
        'weeks':       weeks,
        'total_pl':    total_pl,
        'total_trades':total_trades,
        'trading_days':trading_days,
        'calendar':    cal,
        'year':        year,
        'month':       month,
        'month_name':  calendar.month_name[month],
    }


@calendar_bp.route('/')
@calendar_bp.route('/<int:year>/<int:month>')
@login_required
def index(year=None, month=None):
    user = get_current_user()

    # Check plan — Pro and Elite only
    if user.get('plan', 'normal') == 'normal':
        flash('The trade calendar is available on Pro and Elite plans.', 'warning')
        return redirect(url_for('plans.index'))

    now   = datetime.utcnow()
    year  = year  or now.year
    month = month or now.month

    # Clamp valid month
    if month < 1:  month = 12; year -= 1
    if month > 12: month = 1;  year += 1

    data = get_calendar_data(user['id'], year, month)
    return render_template('calendar.html', data=data, user=user)


@calendar_bp.route('/api/<int:year>/<int:month>')
@login_required
def api_calendar(year, month):
    user_id = session['user_id']
    data    = get_calendar_data(user_id, year, month)
    return jsonify(data)