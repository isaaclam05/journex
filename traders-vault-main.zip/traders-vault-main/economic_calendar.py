"""
Traders Vault - Economic Calendar Module
==========================================
Fetches high-impact forex news events from ForexFactory
and Investing.com RSS feeds. Free, no API key needed.
"""

from flask import Blueprint, render_template, jsonify
from auth import login_required, get_current_user
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import json

economic_calendar_bp = Blueprint('economic_calendar', __name__)

# ForexFactory RSS
FF_RSS = 'https://nfs.faireconomy.media/ff_calendar_thisweek.json'

# Fallback curated events
FALLBACK_EVENTS = [
    {'date': 'Mon', 'time': '08:30', 'currency': 'USD', 'impact': 'high',   'event': 'ISM Manufacturing PMI',         'forecast': '48.4', 'previous': '47.8'},
    {'date': 'Tue', 'time': '09:00', 'currency': 'EUR', 'impact': 'high',   'event': 'CPI Flash Estimate y/y',        'forecast': '2.3%', 'previous': '2.2%'},
    {'date': 'Tue', 'time': '13:30', 'currency': 'USD', 'impact': 'high',   'event': 'JOLTS Job Openings',            'forecast': '8.5M', 'previous': '8.8M'},
    {'date': 'Wed', 'time': '13:15', 'currency': 'USD', 'impact': 'high',   'event': 'ADP Non-Farm Employment',       'forecast': '120K', 'previous': '140K'},
    {'date': 'Wed', 'time': '19:00', 'currency': 'USD', 'impact': 'high',   'event': 'FOMC Meeting Minutes',          'forecast': '',     'previous': ''},
    {'date': 'Thu', 'time': '12:45', 'currency': 'EUR', 'impact': 'high',   'event': 'ECB Interest Rate Decision',    'forecast': '3.15%','previous': '3.15%'},
    {'date': 'Thu', 'time': '13:30', 'currency': 'USD', 'impact': 'high',   'event': 'Unemployment Claims',           'forecast': '215K', 'previous': '219K'},
    {'date': 'Thu', 'time': '13:30', 'currency': 'GBP', 'impact': 'medium', 'event': 'BOE Gov Bailey Speaks',         'forecast': '',     'previous': ''},
    {'date': 'Fri', 'time': '13:30', 'currency': 'USD', 'impact': 'high',   'event': 'Non-Farm Payrolls',             'forecast': '170K', 'previous': '151K'},
    {'date': 'Fri', 'time': '13:30', 'currency': 'USD', 'impact': 'high',   'event': 'Unemployment Rate',             'forecast': '4.1%', 'previous': '4.1%'},
    {'date': 'Fri', 'time': '13:30', 'currency': 'CAD', 'impact': 'high',   'event': 'Canada Employment Change',      'forecast': '25K',  'previous': '16K'},
    {'date': 'Mon', 'time': '09:30', 'currency': 'GBP', 'impact': 'medium', 'event': 'UK Manufacturing PMI',          'forecast': '44.6', 'previous': '44.2'},
    {'date': 'Tue', 'time': '00:30', 'currency': 'AUD', 'impact': 'high',   'event': 'RBA Interest Rate Decision',    'forecast': '4.10%','previous': '4.10%'},
    {'date': 'Wed', 'time': '06:00', 'currency': 'JPY', 'impact': 'medium', 'event': 'BOJ Summary of Opinions',       'forecast': '',     'previous': ''},
    {'date': 'Thu', 'time': '13:30', 'currency': 'USD', 'impact': 'high',   'event': 'Core CPI m/m',                 'forecast': '0.3%', 'previous': '0.4%'},
]


def fetch_forexfactory():
    """Fetch this week's events from ForexFactory JSON."""
    events = []
    try:
        req = urllib.request.Request(
            FF_RSS,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        )
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode('utf-8'))

        for item in data:
            impact = item.get('impact', '').lower()
            if impact not in ('high', 'medium'):
                continue
            # Parse date
            try:
                dt = datetime.strptime(item.get('date', ''), '%m-%d-%Y')
                date_str = dt.strftime('%a')
                date_full = dt.strftime('%d %b')
            except:
                date_str  = item.get('date', '')
                date_full = date_str

            events.append({
                'date':      date_str,
                'date_full': date_full,
                'time':      item.get('time', 'All Day'),
                'currency':  item.get('country', '').upper(),
                'impact':    impact,
                'event':     item.get('title', ''),
                'forecast':  item.get('forecast', ''),
                'previous':  item.get('previous', ''),
                'actual':    item.get('actual', ''),
            })

        print(f"[Calendar] ForexFactory: {len(events)} events fetched")
        return events
    except Exception as e:
        print(f"[Calendar] ForexFactory error: {e}")
        return []


def get_events():
    """Get events — try ForexFactory first, fall back to curated list."""
    events = fetch_forexfactory()
    if len(events) < 5:
        print("[Calendar] Using fallback events")
        # Add date_full to fallback
        now = datetime.utcnow()
        day_map = {}
        for i in range(7):
            d = now + timedelta(days=i)
            day_map[d.strftime('%a')] = d.strftime('%d %b')
        for e in FALLBACK_EVENTS:
            e['date_full'] = day_map.get(e['date'], e['date'])
            e['actual']    = ''
        return FALLBACK_EVENTS
    return events


@economic_calendar_bp.route('/')
@login_required
def index():
    user   = get_current_user()
    events = get_events()

    # Group by day
    days = {}
    for e in events:
        key = e.get('date_full', e.get('date', ''))
        if key not in days:
            days[key] = []
        days[key].append(e)

    # Today's day name
    today = datetime.utcnow().strftime('%a')

    return render_template('economic_calendar.html',
                           days=days, events=events, today=today, user=user)


@economic_calendar_bp.route('/api')
@login_required
def api():
    return jsonify(get_events())
