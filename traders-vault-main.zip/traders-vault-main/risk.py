"""
Journex - Risk Management Module
========================================
Risk calculator, position sizing, daily loss limit,
drawdown alerts, consecutive loss tracking.
"""

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from auth import login_required, get_current_user
from database import get_db, get_trades
from bson import ObjectId
from datetime import datetime, timedelta

risk_bp = Blueprint('risk', __name__)


def get_risk_data(user_id):
    """Compute risk stats for the user."""
    db   = get_db()
    user = db.users.find_one({'_id': ObjectId(user_id)})
    if not user:
        return {}

    trades   = get_trades(user_id)
    closed   = [t for t in trades if t.get('profit_loss') is not None]
    today    = datetime.utcnow().strftime('%Y-%m-%d')
    today_trades = [t for t in closed if t.get('trade_date', '') == today]

    # Daily P&L
    daily_pl   = round(sum(t['profit_loss'] for t in today_trades), 2)
    daily_limit = float(user.get('daily_loss_limit', 0))

    # Peak balance & drawdown
    starting   = float(user.get('starting_balance', 0))
    total_pl   = round(sum(t['profit_loss'] for t in closed), 2)
    balance    = round(starting + total_pl, 2) if starting else 0

    # Max drawdown
    peak = running = 0
    max_dd = 0
    for t in sorted(closed, key=lambda x: x.get('trade_date', '')):
        running += t['profit_loss']
        if running > peak: peak = running
        dd = peak - running
        if dd > max_dd: max_dd = round(dd, 2)

    dd_pct = round(max_dd / (starting + peak) * 100, 1) if (starting + peak) > 0 else 0

    # Consecutive losses today
    today_sorted = sorted(today_trades, key=lambda x: x.get('created_at', ''))
    consec_losses = 0
    for t in reversed(today_sorted):
        if t['profit_loss'] < 0:
            consec_losses += 1
        else:
            break

    # Lot sizes
    lots = [t.get('lot_size', 0) for t in closed if t.get('lot_size')]
    avg_lot = round(sum(lots) / len(lots), 2) if lots else 0

    # Lots on wins vs losses
    win_lots  = [t.get('lot_size', 0) for t in closed if t.get('profit_loss', 0) > 0 and t.get('lot_size')]
    loss_lots = [t.get('lot_size', 0) for t in closed if t.get('profit_loss', 0) < 0 and t.get('lot_size')]
    avg_win_lot  = round(sum(win_lots)  / len(win_lots),  2) if win_lots  else 0
    avg_loss_lot = round(sum(loss_lots) / len(loss_lots), 2) if loss_lots else 0

    return {
        'balance':       balance,
        'starting':      starting,
        'total_pl':      total_pl,
        'daily_pl':      daily_pl,
        'daily_limit':   daily_limit,
        'daily_hit':     daily_limit > 0 and daily_pl <= -daily_limit,
        'max_drawdown':  max_dd,
        'dd_pct':        dd_pct,
        'dd_alert':      dd_pct >= 10,
        'consec_losses': consec_losses,
        'avg_lot':       avg_lot,
        'avg_win_lot':   avg_win_lot,
        'avg_loss_lot':  avg_loss_lot,
    }


@risk_bp.route('/')
@login_required
def index():
    user      = get_current_user()
    risk_data = get_risk_data(session['user_id'])
    return render_template('risk_calculator.html', user=user, risk=risk_data)


@risk_bp.route('/set-limits', methods=['POST'])
@login_required
def set_limits():
    """Save daily loss limit and drawdown alert threshold."""
    db          = get_db()
    daily_limit = request.form.get('daily_loss_limit', 0)
    dd_threshold= request.form.get('dd_threshold', 15)

    starting_balance = request.form.get('starting_balance', '') or None
    updates = {
        'daily_loss_limit': float(daily_limit)       if daily_limit       else 0,
        'dd_threshold':     float(dd_threshold),
    }
    if starting_balance:
        updates['starting_balance'] = float(starting_balance)

    db.users.update_one({'_id': ObjectId(session['user_id'])}, {'$set': updates})
    flash('Risk limits saved!', 'success')
    return redirect(url_for('risk.index'))


@risk_bp.route('/api/calculate', methods=['POST'])
@login_required
def calculate():
    """Position size calculator API."""
    data = request.json or {}
    try:
        account_size = float(data.get('account_size', 0))
        risk_pct     = float(data.get('risk_pct', 1))
        entry        = float(data.get('entry', 0))
        stop_loss    = float(data.get('stop_loss', 0))
        pip_value    = float(data.get('pip_value', 10))  # Default $10/pip for standard lot

        if not all([account_size, entry, stop_loss]):
            return jsonify({'error': 'Missing required fields'}), 400

        risk_amount  = round(account_size * risk_pct / 100, 2)
        pips_at_risk = round(abs(entry - stop_loss) / 0.0001, 1)
        lot_size     = round(risk_amount / (pips_at_risk * pip_value), 2) if pips_at_risk > 0 else 0
        units        = int(lot_size * 100000)

        return jsonify({
            'risk_amount':  risk_amount,
            'pips_at_risk': pips_at_risk,
            'lot_size':     lot_size,
            'units':        units,
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@risk_bp.route('/api/status')
@login_required
def api_status():
    """Returns current risk status for dashboard banner."""
    data = get_risk_data(session['user_id'])
    return jsonify(data)
