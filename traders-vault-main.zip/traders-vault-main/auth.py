"""
Journex - Authentication Module
======================================
Handles user registration, login, session management,
and account settings (username, password, delete).
"""

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db, get_user_by_email, get_user_by_id, get_user_by_username, create_user
from bson import ObjectId
from datetime import datetime, timedelta
import functools

# ─── Brute Force Protection ───────────────────────────────────
MAX_ATTEMPTS  = 5       # Max failed attempts before lockout
LOCKOUT_MINS  = 15      # Lockout duration in minutes

def get_client_ip():
    return request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()

def check_rate_limit(email):
    """Returns (is_locked, attempts_left, unlock_time)."""
    db  = get_db()
    key = f"{email}:{get_client_ip()}"
    doc = db.login_attempts.find_one({'key': key})
    if not doc:
        return False, MAX_ATTEMPTS, None
    # Check if locked
    if doc.get('locked_until') and doc['locked_until'] > datetime.utcnow():
        remaining = int((doc['locked_until'] - datetime.utcnow()).total_seconds() // 60) + 1
        return True, 0, remaining
    # Reset if lockout expired
    if doc.get('locked_until') and doc['locked_until'] <= datetime.utcnow():
        db.login_attempts.delete_one({'key': key})
        return False, MAX_ATTEMPTS, None
    attempts_left = MAX_ATTEMPTS - doc.get('attempts', 0)
    return False, attempts_left, None

def record_failed_attempt(email):
    """Record a failed login attempt. Lock after MAX_ATTEMPTS."""
    db  = get_db()
    key = f"{email}:{get_client_ip()}"
    doc = db.login_attempts.find_one({'key': key})
    attempts = (doc.get('attempts', 0) if doc else 0) + 1
    update = {'$set': {'key': key, 'attempts': attempts, 'last_attempt': datetime.utcnow()}}
    if attempts >= MAX_ATTEMPTS:
        update['$set']['locked_until'] = datetime.utcnow() + timedelta(minutes=LOCKOUT_MINS)
    db.login_attempts.update_one({'key': key}, update, upsert=True)
    return attempts

def clear_attempts(email):
    """Clear failed attempts after successful login."""
    db  = get_db()
    key = f"{email}:{get_client_ip()}"
    db.login_attempts.delete_one({'key': key})

auth_bp = Blueprint('auth', __name__)


# ─── Decorators ──────────────────────────────────────────────
def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        return view(**kwargs)
    return wrapped_view


def is_admin():
    return session.get('role') == 'admin'


def get_current_user():
    if 'user_id' in session:
        return get_user_by_id(session['user_id'])
    return None


# ─── Register ────────────────────────────────────────────────
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm  = request.form.get('confirm_password', '')

        error = None
        if not username or len(username) < 3:
            error = 'Username must be at least 3 characters.'
        elif not email:
            error = 'Email is required.'
        elif not password or len(password) < 6:
            error = 'Password must be at least 6 characters.'
        elif password != confirm:
            error = 'Passwords do not match.'
        elif get_user_by_email(email):
            error = 'An account with that email already exists.'
        elif get_user_by_username(username):
            error = 'That username is already taken.'

        if error:
            flash(error, 'error')
        else:
            hashed  = generate_password_hash(password)
            user_id = create_user(username, email, hashed)
            session['user_id']  = user_id
            session['username'] = username
            session['plan']     = 'normal'
            session['role']     = 'user'

            # Send welcome email
            try:
                from email_module import send_welcome_email
                send_welcome_email(email, username)
            except Exception as e:
                print(f'[Auth] Welcome email error: {e}')

            flash(f'Welcome to Journex, {username}!', 'success')
            return redirect(url_for('dashboard.index'))

    return render_template('register.html')


# ─── Login ───────────────────────────────────────────────────
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        # ── Check rate limit ──────────────────────────────────
        is_locked, attempts_left, unlock_time = check_rate_limit(email)
        if is_locked:
            flash(f'Too many failed attempts. Account locked for {unlock_time} more minute(s). Try again later.', 'error')
            return render_template('login.html', locked=True)

        user = get_user_by_email(email)

        if user is None or not check_password_hash(user['password'], password):
            attempts = record_failed_attempt(email)
            remaining = MAX_ATTEMPTS - attempts
            if remaining <= 0:
                flash(f'Too many failed attempts. Account locked for {LOCKOUT_MINS} minutes.', 'error')
            elif remaining <= 2:
                flash(f'Invalid email or password. {remaining} attempt(s) remaining before lockout.', 'error')
            else:
                flash('Invalid email or password.', 'error')
        else:
            clear_attempts(email)
            session.clear()
            session['user_id']  = user['id']
            session['username'] = user['username']
            session['plan']     = user.get('plan', 'normal')
            session['role']     = user.get('role', 'user')
            flash(f'Welcome back, {user["username"]}!', 'success')
            return redirect(url_for('dashboard.index'))

    return render_template('login.html')


# ─── Logout ──────────────────────────────────────────────────
@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home.index'))


# ─── Profile ─────────────────────────────────────────────────
@auth_bp.route('/profile')
@login_required
def profile():
    user  = get_current_user()
    db    = get_db()
    count = db.trades.count_documents({'user_id': session['user_id']})
    return render_template('profile.html', user=user, trade_count=count)


# ─── Update Username ─────────────────────────────────────────
@auth_bp.route('/update-username', methods=['POST'])
@login_required
def update_username():
    new_username = request.form.get('username', '').strip()
    if not new_username or len(new_username) < 3:
        flash('Username must be at least 3 characters.', 'error')
        return redirect(url_for('auth.profile'))

    existing = get_user_by_username(new_username)
    if existing and existing['id'] != session['user_id']:
        flash('That username is already taken.', 'error')
        return redirect(url_for('auth.profile'))

    db = get_db()
    db.users.update_one({'_id': ObjectId(session['user_id'])},
                        {'$set': {'username': new_username}})
    session['username'] = new_username
    flash('Username updated!', 'success')
    return redirect(url_for('auth.profile'))


# ─── Update Password ─────────────────────────────────────────
@auth_bp.route('/update-password', methods=['POST'])
@login_required
def update_password():
    current_pw = request.form.get('current_password', '')
    new_pw     = request.form.get('new_password', '')
    confirm_pw = request.form.get('confirm_password', '')

    user = get_user_by_id(session['user_id'])
    if not check_password_hash(user['password'], current_pw):
        flash('Current password is incorrect.', 'error')
        return redirect(url_for('auth.profile'))
    if len(new_pw) < 6:
        flash('New password must be at least 6 characters.', 'error')
        return redirect(url_for('auth.profile'))
    if new_pw != confirm_pw:
        flash('Passwords do not match.', 'error')
        return redirect(url_for('auth.profile'))

    db = get_db()
    db.users.update_one({'_id': ObjectId(session['user_id'])},
                        {'$set': {'password': generate_password_hash(new_pw)}})
    flash('Password updated successfully!', 'success')
    return redirect(url_for('auth.profile'))


# ─── Delete Account ──────────────────────────────────────────
@auth_bp.route('/delete-account', methods=['POST'])
@login_required
def delete_account():
    confirm  = request.form.get('confirm_username', '')
    if confirm != session.get('username'):
        flash('Username did not match. Account not deleted.', 'error')
        return redirect(url_for('auth.profile'))

    user_id = session['user_id']
    db = get_db()

    # Delete all chart images from GridFS
    trades = list(db.trades.find({'user_id': user_id}))
    from database import delete_image
    for t in trades:
        if t.get('image_id'):
            delete_image(t['image_id'])

    # Delete all user data
    db.trades.delete_many({'user_id': user_id})
    db.alerts.delete_many({'user_id': user_id})
    try:
        db.tokens.delete_many({'user_id': user_id})
    except: pass
    db.users.delete_one({'_id': ObjectId(user_id)})

    session.clear()
    flash('Your account has been permanently deleted.', 'info')
    return redirect(url_for('home.index'))


# ─── Forgot Password ─────────────────────────────────────
@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        user  = get_user_by_email(email)
        if user:
            try:
                from email_module import send_password_reset_email
                import secrets
                token = secrets.token_urlsafe(32)
                db    = get_db()
                db.tokens.update_one(
                    {'user_id': user['id'], 'type': 'reset'},
                    {'$set': {'user_id': user['id'], 'token': token, 'type': 'reset',
                              'created_at': datetime.utcnow()}},
                    upsert=True
                )
                send_password_reset_email(email, user['username'], token)
            except Exception as e:
                print(f'[Auth] Password reset error: {e}')
        # Always show success to prevent email enumeration
        flash('If that email exists, a reset link has been sent.', 'success')
        return redirect(url_for('auth.login'))
    return render_template('forgot_password.html')


# ─── Reset Password ───────────────────────────────────────
@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    db  = get_db()
    doc = db.tokens.find_one({'token': token, 'type': 'reset'})
    if not doc:
        flash('Invalid or expired reset link.', 'error')
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        new_pw  = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        if len(new_pw) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return redirect(request.url)
        if new_pw != confirm:
            flash('Passwords do not match.', 'error')
            return redirect(request.url)
        db.users.update_one(
            {'_id': ObjectId(doc['user_id'])},
            {'$set': {'password': generate_password_hash(new_pw)}}
        )
        db.tokens.delete_one({'token': token})
        flash('Password reset! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('reset_password.html', token=token)
