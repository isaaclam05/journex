"""
Traders Vault - Plans & Billing Module
=========================================
Full Stripe checkout integration.
"""

import os
import stripe
from flask import (Blueprint, render_template, session, redirect,
                   url_for, request, flash, jsonify, current_app)
from auth import login_required, get_current_user
from database import update_user_plan, get_db

plans_bp = Blueprint('plans', __name__)

PLANS = {
    'normal': {
        'name':        'Starter',
        'price':       9.99,
        'price_id':    'price_1THLIRRS6EWULGKM3xSJ9Lls',
        'color':       '#3b82f6',
        'description': 'Perfect for beginner traders',
        'features': [
            'Up to 50 trades/month',
            'Basic journal entry',
            'Trade history table',
            'Export to CSV',
            'Email support',
        ],
        'excluded': [
            'Advanced analytics',
            'Chart image uploads',
            'News feed',
            'AI analysis',
        ]
    },
    'medium': {
        'name':        'Pro',
        'price':       24.99,
        'price_id':    'price_1THLIxRS6EWULGKMyWi5aFn5',
        'color':       '#06b6d4',
        'description': 'For serious and active traders',
        'features': [
            'Unlimited trades',
            'Full analytics dashboard',
            'Chart image uploads',
            'Market news feed',
            'CSV import & export',
            'Session analysis',
            'Priority email support',
        ],
        'excluded': [
            'AI trade analysis',
            'Advanced AI statistics',
        ]
    },
    'high': {
        'name':        'Elite',
        'price':       59.99,
        'price_id':    'price_1THLJBRS6EWULGKMAhWUa1HX',
        'color':       '#8b5cf6',
        'description': 'For professional traders & funds',
        'features': [
            'Everything in Pro',
            'AI trade analysis',
            'Advanced AI statistics',
            'Performance predictions',
            'Risk management alerts',
            'API access',
            'Dedicated support',
            'White-label option',
        ],
        'excluded': []
    }
}


def get_stripe():
    # ⚠️ REPLACE THIS WITH YOUR REAL sk_live_ KEY
    stripe.api_key = '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'
    return stripe


@plans_bp.route('/')
def index():
    user = get_current_user() if 'user_id' in session else None
    return render_template('plans.html', plans=PLANS, user=user)


@plans_bp.route('/checkout/<plan_key>')
@login_required
def checkout(plan_key):
    if plan_key not in PLANS:
        flash('Invalid plan selected.', 'error')
        return redirect(url_for('plans.index'))

    plan = PLANS[plan_key]
    user = get_current_user()
    s    = get_stripe()

    try:
        checkout_session = s.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price':    plan['price_id'],
                'quantity': 1,
            }],
            mode='subscription',
            success_url=url_for('plans.success', _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('plans.index', _external=True),
            customer_email=user['email'],
            metadata={
                'user_id':  user['id'],
                'plan_key': plan_key,
            }
        )
        return redirect(checkout_session.url, code=303)

    except Exception as e:
        import traceback
        print(f"[Stripe] Checkout error: {e}")
        print(traceback.format_exc())
        flash(f'Payment error: {str(e)}', 'error')
        return redirect(url_for('plans.index'))


@plans_bp.route('/success')
@login_required
def success():
    session_id = request.args.get('session_id', '')
    s          = get_stripe()

    try:
        checkout_session = s.checkout.Session.retrieve(session_id)
        plan_key         = checkout_session.metadata.get('plan_key', 'normal')
        user_id          = checkout_session.metadata.get('user_id')
        customer_id      = checkout_session.customer
        subscription_id  = checkout_session.subscription

        update_user_plan(user_id, plan_key, customer_id, subscription_id)
        session['plan'] = plan_key

        plan_name = PLANS.get(plan_key, {}).get('name', 'Pro')

        try:
            from email_module import send_payment_receipt_email
            user = get_current_user()
            send_payment_receipt_email(
                user['email'],
                user['username'],
                plan_name,
                PLANS[plan_key]['price']
            )
        except Exception as e:
            print(f"[Stripe] Receipt email error: {e}")

        flash(f'Payment successful! Welcome to the {plan_name} plan.', 'success')

    except Exception as e:
        print(f"[Stripe] Success page error: {e}")
        flash('Payment confirmed! Your plan will be updated shortly.', 'success')

    return redirect(url_for('journal.index'))


@plans_bp.route('/cancel')
@login_required
def cancel_subscription():
    user = get_current_user()
    s    = get_stripe()

    try:
        sub_id = user.get('stripe_subscription_id')
        if sub_id:
            s.Subscription.modify(sub_id, cancel_at_period_end=True)
            flash('Your subscription will be cancelled at the end of the billing period.', 'info')
        else:
            flash('No active subscription found.', 'warning')
    except Exception as e:
        print(f"[Stripe] Cancel error: {e}")
        flash('Could not cancel subscription. Please contact support.', 'error')

    return redirect(url_for('auth.profile'))


@plans_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload        = request.get_data()
    sig_header     = request.headers.get('Stripe-Signature', '')
    webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET', '')
    s              = get_stripe()

    try:
        if webhook_secret:
            event = s.Webhook.construct_event(payload, sig_header, webhook_secret)
        else:
            import json
            event = json.loads(payload)

        if event['type'] == 'checkout.session.completed':
            cs       = event['data']['object']
            user_id  = cs['metadata'].get('user_id')
            plan_key = cs['metadata'].get('plan_key', 'normal')
            if user_id:
                update_user_plan(user_id, plan_key,
                                 cs.get('customer'),
                                 cs.get('subscription'))

        elif event['type'] == 'customer.subscription.deleted':
            sub     = event['data']['object']
            cust_id = sub.get('customer')
            db      = get_db()
            db.users.update_one(
                {'stripe_customer_id': cust_id},
                {'$set': {'plan': 'normal', 'stripe_subscription_id': None}}
            )

    except Exception as e:
        print(f"[Stripe] Webhook error: {e}")
        return jsonify({'error': str(e)}), 400

    return jsonify({'status': 'received'}), 200


@plans_bp.route('/api/plans')
def api_plans():
    return jsonify(PLANS)