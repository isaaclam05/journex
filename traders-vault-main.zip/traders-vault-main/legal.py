"""
Traders Vault - Legal Pages Module
====================================
Routes for Terms of Service, Privacy Policy, and Trading Risk Disclaimer.
"""

from flask import Blueprint, render_template

legal_bp = Blueprint('legal', __name__)


@legal_bp.route('/terms')
def terms():
    return render_template('terms.html')


@legal_bp.route('/privacy')
def privacy():
    return render_template('privacy.html')


@legal_bp.route('/disclaimer')
def disclaimer():
    return render_template('disclaimer.html')
