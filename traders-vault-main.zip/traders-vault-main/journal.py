"""
Journex - Journal Module
================================
Full MongoDB backend — trades and images stored in MongoDB.
Includes: trade tags, entry/exit time, search, bulk delete,
copy trade, setup notes template, consecutive loss alert.
"""

from flask import (Blueprint, render_template, request, redirect,
                   url_for, session, flash, jsonify, Response)
from werkzeug.utils import secure_filename
from database import (create_trade, get_trades, get_trade_by_id,
                      update_trade, delete_trade_by_id, save_image, get_image,
                      delete_image, get_trade_by_image_id, is_valid_image_id, get_db)
from auth import login_required, get_current_user
from bson import ObjectId
import csv, io
from datetime import datetime

journal_bp = Blueprint('journal', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'}
ALLOWED_PAIRS = [
    'EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD', 'NZDUSD', 'USDCAD',
    'EURGBP', 'EURJPY', 'GBPJPY', 'XAUUSD', 'XAGUSD', 'BTCUSD', 'ETHUSD',
    'US30', 'NAS100', 'SPX500', 'OIL', 'Other'
]
SESSIONS   = ['Asian', 'London', 'New York', 'London/NY Overlap', 'Asian/London Overlap']
DOW_NAMES  = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
TRADE_TAGS = ['Breakout', 'Reversal', 'Trend Follow', 'Scalp', 'News Trade',
              'Support/Resistance', 'Fibonacci', 'EMA Cross', 'Pin Bar',
              'Engulfing', 'Double Top/Bottom', 'Head & Shoulders', 'Other']

NOTES_TEMPLATE = """Bias: 
Confluence: 
Entry reason: 
What I did well: 
Mistake / What to improve: """


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Pip values per standard lot for common pairs (USD account)
PIP_VALUES = {
    'EURUSD': 10.0, 'GBPUSD': 10.0, 'AUDUSD': 10.0, 'NZDUSD': 10.0,
    'USDCAD': 7.7,  'USDCHF': 10.8, 'USDJPY': 6.5,
    'EURGBP': 13.0, 'EURJPY': 6.5,  'GBPJPY': 6.5,
    'XAUUSD': 10.0, 'XAGUSD': 50.0,
    'BTCUSD': 1.0,  'ETHUSD': 1.0,
    'NAS100': 1.0,  'US30': 1.0,    'SPX500': 1.0, 'US500': 1.0,
    'OIL':    10.0,
}

def calc_pl_from_lots(pair, direction, entry, sl_or_exit, lot_size):
    """Calculate P&L from lot size, entry and exit/SL price."""
    try:
        entry    = float(entry)
        exit_p   = float(sl_or_exit)
        lot_size = float(lot_size)
        pair     = pair.upper()

        # Pip size — JPY pairs use 0.01, others use 0.0001
        pip_size = 0.01 if 'JPY' in pair else 0.0001
        # For indices, gold, crypto — point value not pip
        if pair in ('XAUUSD', 'NAS100', 'US30', 'SPX500', 'US500', 'OIL'):
            pip_size = 1.0
        if pair in ('BTCUSD', 'ETHUSD'):
            pip_size = 1.0

        pip_value = PIP_VALUES.get(pair, 10.0)
        direction = direction.upper()

        if direction == 'BUY':
            pips = (exit_p - entry) / pip_size
        else:
            pips = (entry - exit_p) / pip_size

        pl = round(pips * pip_value * lot_size, 2)
        return pl
    except Exception as e:
        print(f"[PL Calc] Error: {e}")
        return None


def calc_rr(entry, sl, tp, direction):
    try:
        entry, sl, tp = float(entry), float(sl), float(tp)
        risk   = (entry - sl) if direction.upper() == 'BUY' else (sl - entry)
        reward = (tp - entry) if direction.upper() == 'BUY' else (entry - tp)
        return round(reward / risk, 2) if risk > 0 else None
    except (ValueError, ZeroDivisionError):
        return None


def handle_image_upload(file, user_id, trade_date):
    if not file or not file.filename or not allowed_file(file.filename):
        return None
    filename     = secure_filename(file.filename)
    ext          = filename.rsplit('.', 1)[-1].lower()
    content_type = 'image/jpeg' if ext == 'jpg' else f'image/{ext}'
    try:
        return save_image(file, filename, user_id, trade_date, content_type)
    except Exception as e:
        print(f"[Journal] Image upload error: {e}")
        return None


def get_journal_stats(trades):
    closed   = [t for t in trades if t.get('profit_loss') is not None]
    wins     = [t for t in closed if t['profit_loss'] > 0]
    losses   = [t for t in closed if t['profit_loss'] < 0]
    total_pl = round(sum(t['profit_loss'] for t in closed), 2)
    win_rate = round(len(wins) / len(closed) * 100, 1) if closed else 0
    rr_vals  = [t['rr_ratio'] for t in trades if t.get('rr_ratio')]
    avg_rr   = round(sum(rr_vals) / len(rr_vals), 2) if rr_vals else 0

    # Consecutive losses (most recent streak)
    sorted_closed = sorted(closed, key=lambda x: x.get('trade_date','') + x.get('created_at',''), reverse=True)
    consec_losses = 0
    for t in sorted_closed:
        if t['profit_loss'] < 0:
            consec_losses += 1
        else:
            break

    # Tag stats
    tag_stats = {}
    for t in closed:
        for tag in (t.get('tags') or []):
            if tag not in tag_stats:
                tag_stats[tag] = {'trades': 0, 'wins': 0, 'pl': 0.0}
            tag_stats[tag]['trades'] += 1
            tag_stats[tag]['pl']     += t['profit_loss']
            if t['profit_loss'] > 0:
                tag_stats[tag]['wins'] += 1
    for k in tag_stats:
        tag_stats[k]['pl']       = round(tag_stats[k]['pl'], 2)
        tag_stats[k]['win_rate'] = round(tag_stats[k]['wins'] / tag_stats[k]['trades'] * 100, 1)

    # DOW stats
    dow_data = {i: {'trades': 0, 'wins': 0, 'pl': 0.0} for i in range(7)}
    for t in closed:
        d = t.get('trade_date', '')
        if d:
            try:
                dow = datetime.strptime(d, '%Y-%m-%d').weekday()
                dow_data[dow]['trades'] += 1
                dow_data[dow]['pl']      = round(dow_data[dow]['pl'] + t['profit_loss'], 2)
                if t['profit_loss'] > 0:
                    dow_data[dow]['wins'] += 1
            except: pass

    dow_stats = []
    for i in range(7):
        d  = dow_data[i]
        wr = round(d['wins'] / d['trades'] * 100, 1) if d['trades'] > 0 else 0
        dow_stats.append({'day': DOW_NAMES[i], 'short': DOW_NAMES[i][:3],
                          'trades': d['trades'], 'win_rate': wr, 'pl': d['pl']})

    return {
        'total': len(trades), 'wins': len(wins), 'losses': len(losses),
        'total_pl': total_pl, 'win_rate': win_rate, 'avg_rr': avg_rr,
        'dow_stats': dow_stats, 'tag_stats': tag_stats,
        'consec_losses': consec_losses,
    }


def check_consecutive_losses(user_id, trades):
    """Send email alert after 3+ consecutive losses today."""
    today  = datetime.utcnow().strftime('%Y-%m-%d')
    closed = [t for t in trades if t.get('profit_loss') is not None
              and t.get('trade_date') == today]
    sorted_t = sorted(closed, key=lambda x: x.get('created_at',''), reverse=True)
    count = 0
    for t in sorted_t:
        if t['profit_loss'] < 0: count += 1
        else: break
    if count == 3:
        try:
            from database import get_user_by_id
            from email_module import send_consecutive_loss_email
            user    = get_user_by_id(user_id)
            daily_pl = round(sum(t['profit_loss'] for t in closed), 2)
            last_pair = sorted_t[0].get('pair','') if sorted_t else ''
            send_consecutive_loss_email(user['email'], user['username'], count, last_pair, daily_pl)
        except Exception as e:
            print(f"[Journal] Consecutive loss email error: {e}")


# ─── Serve Image ─────────────────────────────────────────
@journal_bp.route('/image/<image_id>')
@login_required
def serve_image(image_id):
    if not is_valid_image_id(image_id):
        return "Invalid image ID", 400
    trade = get_trade_by_image_id(image_id, session['user_id'])
    if not trade:
        return "Not found or access denied", 404
    data, content_type = get_image(image_id)
    if data is None:
        return "Image not found", 404
    return Response(data, mimetype=content_type)


# ─── Journal Index ────────────────────────────────────────
@journal_bp.route('/')
@login_required
def index():
    user_id = session['user_id']
    user    = get_current_user()

    # Search & filter
    search   = request.args.get('search', '').strip()
    tag_filter = request.args.get('tag', '').strip()
    pair_filter = request.args.get('pair', '').strip()
    result_filter = request.args.get('result', '').strip()

    trades = get_trades(user_id)

    # Apply filters
    if search:
        sl = search.lower()
        trades = [t for t in trades if
                  sl in t.get('pair','').lower() or
                  sl in t.get('notes','').lower() or
                  sl in t.get('trade_date','') or
                  sl in (t.get('session') or '').lower() or
                  any(sl in tag.lower() for tag in (t.get('tags') or []))]
    if tag_filter:
        trades = [t for t in trades if tag_filter in (t.get('tags') or [])]
    if pair_filter:
        trades = [t for t in trades if t.get('pair','') == pair_filter]
    if result_filter == 'win':
        trades = [t for t in trades if t.get('profit_loss') and t['profit_loss'] > 0]
    elif result_filter == 'loss':
        trades = [t for t in trades if t.get('profit_loss') and t['profit_loss'] < 0]

    all_trades = get_trades(user_id)
    stats      = get_journal_stats(all_trades)

    # All tags used by this user
    used_tags = set()
    for t in all_trades:
        for tag in (t.get('tags') or []):
            used_tags.add(tag)

    return render_template('journal.html',
                           trades=trades, pairs=ALLOWED_PAIRS,
                           sessions=SESSIONS, user=user, stats=stats,
                           trade_tags=TRADE_TAGS, used_tags=sorted(used_tags),
                           is_valid_image_id=is_valid_image_id,
                           search=search, tag_filter=tag_filter,
                           pair_filter=pair_filter, result_filter=result_filter,
                           notes_template=NOTES_TEMPLATE)


# ─── Trade Detail Page ────────────────────────────────────
@journal_bp.route('/trade/<trade_id>')
@login_required
def trade_detail(trade_id):
    trade = get_trade_by_id(trade_id, session['user_id'])
    if not trade:
        flash('Trade not found.', 'error')
        return redirect(url_for('journal.index'))
    return render_template('trade_detail.html', trade=trade, user=get_current_user(),
                           is_valid_image_id=is_valid_image_id,
                           pairs=ALLOWED_PAIRS, sessions=SESSIONS,
                           trade_tags=TRADE_TAGS)


# ─── Add Trade ────────────────────────────────────────────
@journal_bp.route('/add', methods=['POST'])
@login_required
def add_trade():
    user_id    = session['user_id']
    pair       = request.form.get('pair', '').upper()
    direction  = request.form.get('direction', '').capitalize()
    entry      = request.form.get('entry_price', '')
    sl         = request.form.get('stop_loss', '')   or None
    tp         = request.form.get('take_profit', '') or None
    pl         = request.form.get('profit_loss', '') or None
    session_   = request.form.get('session', '')
    notes      = request.form.get('notes', '')
    trade_date = request.form.get('trade_date', '')
    entry_time = request.form.get('entry_time', '') or None
    exit_time  = request.form.get('exit_time', '')  or None
    lot_size   = request.form.get('lot_size', '')   or None
    utc_offset = request.form.get('utc_offset', '') or None
    tags       = request.form.getlist('tags')

    if not pair or not direction or not entry or not trade_date:
        flash('Pair, direction, entry price, and date are required.', 'error')
        return redirect(url_for('journal.index'))

    rr       = calc_rr(entry, sl, tp, direction) if sl and tp else None
    image_id = None
    if 'chart_image' in request.files:
        image_id = handle_image_upload(request.files['chart_image'], user_id, trade_date)

    # Calculate trade duration
    duration_mins = None
    if entry_time and exit_time:
        try:
            et = datetime.strptime(entry_time, '%H:%M')
            xt = datetime.strptime(exit_time,  '%H:%M')
            duration_mins = int((xt - et).total_seconds() / 60)
        except: pass

    # Calculate P&L from lot size + exit price if provided
    exit_price = request.form.get('exit_price', '') or None
    if lot_size and exit_price and entry:
        calculated_pl = calc_pl_from_lots(pair, direction, entry, exit_price, lot_size)
        if calculated_pl is not None:
            pl = calculated_pl

    db = get_db()
    db.trades.insert_one({
        'user_id':      user_id,
        'pair':         pair,
        'direction':    direction,
        'entry_price':  float(entry),
        'stop_loss':    float(sl)       if sl       else None,
        'take_profit':  float(tp)       if tp       else None,
        'rr_ratio':     rr,
        'profit_loss':  float(pl)       if pl       else None,
        'session':      session_ or '',
        'notes':        notes or '',
        'image_id':     image_id,
        'trade_date':   trade_date,
        'entry_time':   entry_time,
        'exit_time':    exit_time,
        'duration_mins':duration_mins,
        'utc_offset':   utc_offset,
        'lot_size':     float(lot_size) if lot_size else None,
        'tags':         tags,
        'created_at':   datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
    })

    # Check consecutive losses
    all_trades = get_trades(user_id)
    check_consecutive_losses(user_id, all_trades)

    flash('Trade logged!' + (' Chart saved.' if image_id else ''), 'success')
    return redirect(url_for('journal.index'))


# ─── Copy Trade ───────────────────────────────────────────
@journal_bp.route('/copy/<trade_id>', methods=['POST'])
@login_required
def copy_trade(trade_id):
    user_id = session['user_id']
    trade   = get_trade_by_id(trade_id, user_id)
    if not trade:
        flash('Trade not found.', 'error')
        return redirect(url_for('journal.index'))

    db = get_db()
    new_trade = {k: v for k, v in trade.items() if k not in ('id', '_id', 'created_at', 'trade_date')}
    new_trade['user_id']    = user_id
    new_trade['trade_date'] = datetime.utcnow().strftime('%Y-%m-%d')
    new_trade['created_at'] = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    new_trade['profit_loss'] = None
    new_trade['image_id']   = None
    new_trade['notes']      = f"[Copied from {trade['trade_date']}] " + (trade.get('notes',''))
    db.trades.insert_one(new_trade)

    flash('Trade copied! Edit the details and add your result.', 'success')
    return redirect(url_for('journal.index'))


# ─── Edit Trade ───────────────────────────────────────────
@journal_bp.route('/edit/<trade_id>', methods=['GET', 'POST'])
@login_required
def edit_trade(trade_id):
    user_id = session['user_id']
    trade   = get_trade_by_id(trade_id, user_id)
    if not trade:
        flash('Trade not found.', 'error')
        return redirect(url_for('journal.index'))

    if request.method == 'POST':
        pair       = request.form.get('pair', '').upper()
        direction  = request.form.get('direction', '').capitalize()
        entry      = request.form.get('entry_price', '')
        sl         = request.form.get('stop_loss', '')   or None
        tp         = request.form.get('take_profit', '') or None
        pl         = request.form.get('profit_loss', '') or None
        session_   = request.form.get('session', '')
        notes      = request.form.get('notes', '')
        trade_date = request.form.get('trade_date', '')
        entry_time = request.form.get('entry_time', '') or None
        exit_time  = request.form.get('exit_time', '')  or None
        lot_size   = request.form.get('lot_size', '')   or None
        utc_offset = request.form.get('utc_offset', '') or None
        tags       = request.form.getlist('tags')
        rr         = calc_rr(entry, sl, tp, direction) if sl and tp else None

        duration_mins = None
        if entry_time and exit_time:
            try:
                et = datetime.strptime(entry_time, '%H:%M')
                xt = datetime.strptime(exit_time,  '%H:%M')
                duration_mins = int((xt - et).total_seconds() / 60)
            except: pass

        # Recalculate P&L from lot size + exit price
        exit_price = request.form.get('exit_price', '') or None
        if lot_size and exit_price and entry:
            calculated_pl = calc_pl_from_lots(pair, direction, entry, exit_price, lot_size)
            if calculated_pl is not None:
                pl = calculated_pl

        image_id = trade.get('image_id')
        if 'chart_image' in request.files:
            new_image = handle_image_upload(request.files['chart_image'], user_id, trade_date)
            if new_image:
                delete_image(image_id)
                image_id = new_image

        update_trade(trade_id, user_id, {
            'pair': pair, 'direction': direction,
            'entry_price':  float(entry),
            'stop_loss':    float(sl)       if sl       else None,
            'take_profit':  float(tp)       if tp       else None,
            'rr_ratio':     rr,
            'profit_loss':  float(pl)       if pl       else None,
            'session':      session_, 'notes': notes,
            'image_id':     image_id, 'trade_date': trade_date,
            'entry_time':   entry_time, 'exit_time': exit_time,
            'duration_mins':duration_mins,
            'utc_offset':   utc_offset,
            'lot_size':     float(lot_size) if lot_size else None,
            'tags':         tags,
        })
        flash('Trade updated!', 'success')
        return redirect(url_for('journal.trade_detail', trade_id=trade_id))

    return render_template('edit_trade.html', trade=trade, pairs=ALLOWED_PAIRS,
                           sessions=SESSIONS, trade_tags=TRADE_TAGS,
                           is_valid_image_id=is_valid_image_id)


# ─── Delete Trade ─────────────────────────────────────────
@journal_bp.route('/delete/<trade_id>', methods=['POST'])
@login_required
def delete_trade(trade_id):
    trade = delete_trade_by_id(trade_id, session['user_id'])
    if trade:
        delete_image(trade.get('image_id'))
        flash('Trade deleted.', 'info')
    else:
        flash('Trade not found.', 'error')
    return redirect(url_for('journal.index'))


# ─── Bulk Delete ──────────────────────────────────────────
@journal_bp.route('/bulk-delete', methods=['POST'])
@login_required
def bulk_delete():
    user_id   = session['user_id']
    trade_ids = request.form.getlist('trade_ids')
    deleted   = 0
    for tid in trade_ids:
        trade = delete_trade_by_id(tid, user_id)
        if trade:
            delete_image(trade.get('image_id'))
            deleted += 1
    flash(f'Deleted {deleted} trade(s).', 'info')
    return redirect(url_for('journal.index'))


# ─── Import CSV ───────────────────────────────────────────
@journal_bp.route('/import', methods=['POST'])
@login_required
def import_trades():
    user_id = session['user_id']
    if 'csv_file' not in request.files:
        flash('No file selected.', 'error')
        return redirect(url_for('journal.index'))
    file = request.files['csv_file']
    if not file.filename.endswith('.csv'):
        flash('Please upload a CSV file.', 'error')
        return redirect(url_for('journal.index'))

    stream = io.StringIO(file.stream.read().decode('utf-8'))
    reader = csv.DictReader(stream)
    count = 0; errors = 0
    for row in reader:
        try:
            create_trade(
                user_id=user_id,
                pair=row.get('pair','').upper(),
                direction=row.get('direction','').capitalize(),
                entry_price=float(row.get('entry_price',0)),
                stop_loss=float(row['stop_loss'])    if row.get('stop_loss')    else None,
                take_profit=float(row['take_profit']) if row.get('take_profit') else None,
                rr_ratio=float(row['rr_ratio'])      if row.get('rr_ratio')    else None,
                profit_loss=float(row['profit_loss']) if row.get('profit_loss') else None,
                session=row.get('session',''),
                notes=row.get('notes',''),
                trade_date=row.get('trade_date','')
            )
            count += 1
        except Exception:
            errors += 1
    flash(f'Imported {count} trades. {errors} rows skipped.', 'success' if count else 'warning')
    return redirect(url_for('journal.index'))


# ─── Export CSV ───────────────────────────────────────────
@journal_bp.route('/export')
@login_required
def export_trades():
    trades = get_trades(session['user_id'])
    def generate():
        cols = ['trade_date','pair','direction','entry_price','stop_loss',
                'take_profit','rr_ratio','profit_loss','session','notes',
                'entry_time','exit_time','duration_mins','lot_size','tags','created_at']
        yield ','.join(cols) + '\n'
        for t in trades:
            row = []
            for c in cols:
                val = t.get(c,'')
                if val is None: val = ''
                if isinstance(val, list): val = '|'.join(val)
                val = str(val)
                if ',' in val or '\n' in val: val = f'"{val}"'
                row.append(val)
            yield ','.join(row) + '\n'
    filename = f"trades_export_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return Response(generate(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename={filename}'})


# ─── CSV Template ─────────────────────────────────────────
@journal_bp.route('/csv-template')
@login_required
def csv_template():
    def generate():
        cols = ['trade_date','pair','direction','entry_price','stop_loss',
                'take_profit','rr_ratio','profit_loss','session','notes']
        yield ','.join(cols) + '\n'
        yield '2026-04-01,EURUSD,Buy,1.08500,1.08200,1.09100,2.0,250.00,London,Example winning trade\n'
        yield '2026-04-01,XAUUSD,Sell,2310.00,2320.00,2290.00,2.0,-150.00,New York,Example losing trade\n'
    return Response(generate(), mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment; filename=journex_template.csv'})


# ─── Trade Detail API ─────────────────────────────────────
@journal_bp.route('/api/trade/<trade_id>')
@login_required
def trade_detail_api(trade_id):
    trade = get_trade_by_id(trade_id, session['user_id'])
    if not trade:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(trade)
