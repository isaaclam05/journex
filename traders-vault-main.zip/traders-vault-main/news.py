"""
Traders Vault - News Module
=============================
Financial market news via RSS feeds with improved category filtering.
"""

from flask import Blueprint, render_template, session
from auth import login_required, get_current_user
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime

news_bp = Blueprint('news', __name__)

RSS_FEEDS = [
    {'url': 'https://feeds.finance.yahoo.com/rss/2.0/headline?s=EURUSD=X&region=US&lang=en-US',
     'source': 'Yahoo Finance', 'category': 'Forex'},
    {'url': 'https://www.investing.com/rss/news_285.rss',
     'source': 'Investing.com', 'category': 'Forex'},
    {'url': 'https://feeds.reuters.com/reuters/businessNews',
     'source': 'Reuters', 'category': 'Macro'},
    {'url': 'https://feeds.marketwatch.com/marketwatch/topstories/',
     'source': 'MarketWatch', 'category': 'Markets'},
]

# Curated fallback news — always relevant to traders
FALLBACK_NEWS = [
    {'title': 'EUR/USD Tests Key Support at 1.0800 — Watch for Bounce',
     'description': 'The euro faced selling pressure against the dollar as traders await the upcoming ECB rate decision. Technical support at 1.0800 remains critical.',
     'url': 'https://www.investing.com', 'source': 'Investing.com', 'category': 'Forex', 'published': 'Today'},
    {'title': 'GBP/USD Rallies After UK Jobs Data Beats Expectations',
     'description': 'Sterling surged against the dollar after UK employment figures came in stronger than forecast, reducing bets on an early Bank of England rate cut.',
     'url': 'https://www.fxstreet.com', 'source': 'FX Street', 'category': 'Forex', 'published': 'Today'},
    {'title': 'USD/JPY Retreats From Multi-Year Highs on Intervention Fears',
     'description': 'The Japanese yen recovered as intervention speculation from BOJ officials weighed on dollar bulls near key resistance levels.',
     'url': 'https://www.reuters.com', 'source': 'Reuters', 'category': 'Forex', 'published': 'Today'},
    {'title': 'Gold Climbs Toward $3,100 on Safe Haven Demand',
     'description': 'XAU/USD pushed higher as geopolitical tensions and a weaker dollar boosted demand for the precious metal. Key resistance at $3,150.',
     'url': 'https://www.marketwatch.com', 'source': 'MarketWatch', 'category': 'Commodities', 'published': 'Today'},
    {'title': 'Bitcoin Stabilizes Above $80,000 — On-Chain Data Shows Accumulation',
     'description': 'BTC/USD found buyers near $80,000 with on-chain metrics showing accumulation from long-term holders and institutional buyers.',
     'url': 'https://www.coindesk.com', 'source': 'CoinDesk', 'category': 'Crypto', 'published': 'Today'},
    {'title': 'Ethereum Eyes $3,000 as ETF Inflows Accelerate',
     'description': 'ETH/USD approaches key resistance as spot ETF products continue to see net positive inflows for the third consecutive week.',
     'url': 'https://www.coindesk.com', 'source': 'CoinDesk', 'category': 'Crypto', 'published': 'Today'},
    {'title': 'Fed Holds Rates Steady — Powell Signals No Rush to Cut',
     'description': 'The Federal Reserve kept interest rates unchanged, with Chair Powell emphasizing data dependency and no preset path for future adjustments.',
     'url': 'https://www.federalreserve.gov', 'source': 'Reuters', 'category': 'Macro', 'published': 'Today'},
    {'title': 'US CPI Data Comes in Hot — Dollar Strengthens Across the Board',
     'description': 'Inflation data surprised to the upside, pushing back expectations for Fed rate cuts and sending the US dollar higher against major pairs.',
     'url': 'https://www.reuters.com', 'source': 'Reuters', 'category': 'Macro', 'published': 'Today'},
    {'title': 'NAS100 Hits Record High as Tech Earnings Beat Estimates',
     'description': 'The Nasdaq 100 reached new all-time highs driven by strong quarterly earnings from major technology companies, boosting risk sentiment.',
     'url': 'https://www.marketwatch.com', 'source': 'MarketWatch', 'category': 'Stocks', 'published': 'Today'},
    {'title': 'S&P 500 Consolidates Near 5,200 — Key Support Levels to Watch',
     'description': 'The S&P 500 trades in a tight range as investors digest mixed economic data and await the next batch of corporate earnings.',
     'url': 'https://www.marketwatch.com', 'source': 'MarketWatch', 'category': 'Stocks', 'published': 'Today'},
    {'title': 'Oil Prices Rise on OPEC+ Supply Cut Extension',
     'description': 'Crude oil prices jumped after OPEC+ members agreed to extend production cuts, tightening global supply ahead of summer demand season.',
     'url': 'https://www.reuters.com', 'source': 'Reuters', 'category': 'Commodities', 'published': 'Today'},
    {'title': 'AUD/USD Weakens on China Economic Data Disappointment',
     'description': 'The Australian dollar fell against the greenback after Chinese manufacturing PMI data missed expectations, weighing on commodity-linked currencies.',
     'url': 'https://www.fxstreet.com', 'source': 'FX Street', 'category': 'Forex', 'published': 'Today'},
]

CATEGORIES = ['Forex', 'Crypto', 'Stocks', 'Macro', 'Commodities']

# Keywords to filter out irrelevant content
IRRELEVANT_KEYWORDS = [
    'grandmother', 'mom', 'dad', 'recipe', 'cooking', 'travel',
    'celebrity', 'gossip', 'sports score', 'movie', 'tv show',
    'weather', 'fashion', 'beauty', 'health tips', 'relationship'
]

TRADING_KEYWORDS = [
    'usd', 'eur', 'gbp', 'jpy', 'forex', 'currency', 'gold', 'xau',
    'bitcoin', 'btc', 'crypto', 'ethereum', 'stock', 'market', 'fed',
    'rate', 'inflation', 'gdp', 'oil', 'nasdaq', 's&p', 'dow',
    'interest', 'bank', 'ecb', 'boj', 'rba', 'trade', 'economy',
    'dollar', 'yen', 'pound', 'euro', 'commodity', 'index'
]


def is_relevant(article):
    """Filter out non-trading articles."""
    text = (article.get('title', '') + ' ' + article.get('description', '')).lower()
    # Check for irrelevant keywords
    for kw in IRRELEVANT_KEYWORDS:
        if kw in text:
            return False
    # Must contain at least one trading keyword
    return any(kw in text for kw in TRADING_KEYWORDS)


def fetch_rss(feed):
    """Fetch and parse RSS feed, return list of articles."""
    articles = []
    try:
        req = urllib.request.Request(feed['url'], headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as r:
            tree = ET.parse(r)
        root = tree.getroot()
        ns   = {'atom': 'http://www.w3.org/2005/Atom'}
        items = root.findall('.//item') or root.findall('.//atom:entry', ns)
        for item in items[:8]:
            def g(tag):
                el = item.find(tag)
                return el.text.strip() if el is not None and el.text else ''
            title = g('title')
            desc  = g('description') or g('summary') or ''
            url   = g('link') or g('guid')
            pub   = g('pubDate') or g('published') or ''
            if title and url:
                articles.append({
                    'title': title[:120],
                    'description': desc[:200] if desc else 'Click to read more.',
                    'url': url,
                    'source': feed['source'],
                    'category': feed['category'],
                    'published': pub,
                })
    except Exception as e:
        print(f"[News] Feed error {feed['source']}: {e}")
    return articles


@news_bp.route('/')
@login_required
def index():
    user = get_current_user()
    all_news = []

    # Try RSS feeds
    for feed in RSS_FEEDS:
        all_news.extend(fetch_rss(feed))

    # Filter to relevant only
    all_news = [a for a in all_news if is_relevant(a)]

    # Use fallback if not enough real news
    if len(all_news) < 6:
        all_news = FALLBACK_NEWS

    # Deduplicate by title
    seen = set()
    unique = []
    for a in all_news:
        key = a['title'][:50]
        if key not in seen:
            seen.add(key)
            unique.append(a)

    return render_template('news.html', news=unique[:24],
                           categories=CATEGORIES, user=user)