"""
Traders Vault - Habit Tracker Module
=======================================
Track daily trading habits. Streak-based like Duolingo.
"""

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from auth import login_required, get_current_user
from database import get_db
from bson import ObjectId
from datetime import datetime, timedelta

habits_bp = Blueprint('habits', __name__)

DEFAULT_HABITS = [
    {'id': 'review_charts',    'label': 'Reviewed charts before trading',  'icon': '📊'},
    {'id': 'journaled',        'label': 'Logged all trades in journal',     'icon': '📒'},
    {'id': 'followed_plan',    'label': 'Followed my trading plan',         'icon': '✅'},
    {'id': 'no_revenge',       'label': 'No revenge trading today',         'icon': '🧘'},
    {'id': 'checked_news',     'label': 'Checked economic calendar',        'icon': '📰'},
    {'id': 'risk_managed',     'label': 'Respected my risk rules',          'icon': '🛡'},
    {'id': 'reviewed_trades',  'label': 'Reviewed past trades for patterns','icon': '🔍'},
    {'id': 'set_daily_goal',   'label': 'Set a clear goal for today',       'icon': '🎯'},
]


def get_today():
    return (datetime.utcnow() + timedelta(hours=8)).strftime('%Y-%m-%d')  # SGT


def get_habit_log(user_id, date=None):
    db  = get_db()
    day = date or get_today()
    doc = db.habit_logs.find_one({'user_id': user_id, 'date': day})
    return doc


def get_streak(user_id):
    """Calculate current streak — days with at least 5 habits completed."""
    db   = get_db()
    logs = list(db.habit_logs.find({'user_id': user_id}).sort('date', -1).limit(60))
    if not logs:
        return 0

    streak   = 0
    check    = get_today()
    log_map  = {l['date']: l for l in logs}

    while check in log_map:
        completed = sum(1 for h in DEFAULT_HABITS if log_map[check].get('habits', {}).get(h['id']))
        if completed >= 5:
            streak += 1
        else:
            break
        # Go back one day
        dt    = datetime.strptime(check, '%Y-%m-%d') - timedelta(days=1)
        check = dt.strftime('%Y-%m-%d')

    return streak


def get_last_30_days(user_id):
    db   = get_db()
    days = []
    for i in range(29, -1, -1):
        d   = (datetime.utcnow() - timedelta(days=i)).strftime('%Y-%m-%d')
        log = db.habit_logs.find_one({'user_id': user_id, 'date': d})
        completed = 0
        if log:
            completed = sum(1 for h in DEFAULT_HABITS if log.get('habits', {}).get(h['id']))
        days.append({'date': d, 'completed': completed, 'total': len(DEFAULT_HABITS)})
    return days


@habits_bp.route('/')
@login_required
def index():
    user_id  = session['user_id']
    user     = get_current_user()
    today    = get_today()
    log      = get_habit_log(user_id, today)
    streak   = get_streak(user_id)
    history  = get_last_30_days(user_id)

    checked = {}
    if log:
        checked = log.get('habits', {})

    # Completion stats
    total_days     = sum(1 for d in history if d['completed'] >= 5)
    best_day_count = max((d['completed'] for d in history), default=0)

    return render_template('habits.html',
                           user=user, habits=DEFAULT_HABITS,
                           checked=checked, today=today,
                           streak=streak, history=history,
                           total_days=total_days,
                           best_day_count=best_day_count)


@habits_bp.route('/check', methods=['POST'])
@login_required
def check_habit():
    user_id  = session['user_id']
    habit_id = request.form.get('habit_id')
    checked  = request.form.get('checked') == 'true'
    today    = get_today()
    db       = get_db()

    db.habit_logs.update_one(
        {'user_id': user_id, 'date': today},
        {'$set': {
            f'habits.{habit_id}': checked,
            'updated_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        }},
        upsert=True
    )
    return jsonify({'ok': True, 'checked': checked})


@habits_bp.route('/api/streak')
@login_required
def api_streak():
    return jsonify({'streak': get_streak(session['user_id'])})
