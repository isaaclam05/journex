"""
Traders Vault - MongoDB Database Layer
========================================
Full MongoDB backend — stores users, trades, and images.
No SQLite. Everything lives in MongoDB Atlas.
"""

import os
import re
from datetime import datetime
from bson import ObjectId
from pymongo import MongoClient, ASCENDING, DESCENDING
from gridfs import GridFS

# ─────────────────────────────────────────────
# Connection (lazy singleton)
# ─────────────────────────────────────────────
_client = None
_db     = None
_fs     = None


def get_db():
    global _client, _db
    if _db is None:
        uri     = os.environ.get('MONGO_URI', 'mongodb+srv://tradersvault:TraderVault2025!@tradersvault.8qpmmyn.mongodb.net/tradersvault?retryWrites=true&w=majority&appName=tradersvault')
        db_name = os.environ.get('MONGO_DB_NAME', 'tradersvault')
        _client = MongoClient(uri, serverSelectionTimeoutMS=8000)
        _db     = _client[db_name]
    return _db


def get_fs():
    global _fs
    if _fs is None:
        _fs = GridFS(get_db())
    return _fs


def init_db():
    """Create indexes. Safe to call on every startup."""
    db = get_db()
    db.users.create_index('email',    unique=True)
    db.users.create_index('username', unique=True)
    db.trades.create_index([('user_id', ASCENDING), ('trade_date', DESCENDING)])
    try:
        db.login_attempts.create_index('key', unique=True)
        db.login_attempts.create_index('locked_until', expireAfterSeconds=3600)
    except Exception:
        pass
    print("[MongoDB] Database initialized and indexes created.")


def doc_to_dict(doc):
    """Convert MongoDB document to plain dict with string id field."""
    if doc is None:
        return None
    d = dict(doc)
    d['id'] = str(d.pop('_id'))
    return d


# ═══════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════

def create_user(username, email, hashed_password):
    db = get_db()
    try:
        result = db.users.insert_one({
            'username':               username,
            'email':                  email.lower(),
            'password':               hashed_password,
            'plan':                   'normal',
            'role':                   'user',
            'stripe_customer_id':     None,
            'stripe_subscription_id': None,
            'created_at':             datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        })
        return str(result.inserted_id)
    except Exception as e:
        if 'duplicate key' in str(e).lower():
            raise ValueError('Email or username already exists.')
        raise


def get_user_by_email(email):
    db  = get_db()
    doc = db.users.find_one({'email': email.lower()})
    return doc_to_dict(doc)


def get_user_by_id(user_id):
    db = get_db()
    try:
        doc = db.users.find_one({'_id': ObjectId(user_id)})
        return doc_to_dict(doc)
    except Exception:
        return None


def get_user_by_username(username):
    db  = get_db()
    doc = db.users.find_one({'username': username})
    return doc_to_dict(doc)


def update_user_plan(user_id, plan, stripe_customer_id=None, stripe_subscription_id=None):
    db      = get_db()
    updates = {'plan': plan}
    if stripe_customer_id:
        updates['stripe_customer_id'] = stripe_customer_id
    if stripe_subscription_id:
        updates['stripe_subscription_id'] = stripe_subscription_id
    db.users.update_one({'_id': ObjectId(user_id)}, {'$set': updates})


# ═══════════════════════════════════════════════
# TRADES
# ═══════════════════════════════════════════════

def create_trade(user_id, pair, direction, entry_price, stop_loss=None,
                 take_profit=None, rr_ratio=None, profit_loss=None,
                 session=None, notes=None, image_id=None, trade_date=None,
                 entry_time=None, exit_time=None, duration_mins=None, utc_offset=None):
    db     = get_db()
    result = db.trades.insert_one({
        'user_id':       user_id,
        'pair':          pair.upper(),
        'direction':     direction.capitalize(),
        'entry_price':   float(entry_price),
        'stop_loss':     float(stop_loss)    if stop_loss    else None,
        'take_profit':   float(take_profit)  if take_profit  else None,
        'rr_ratio':      float(rr_ratio)     if rr_ratio     else None,
        'profit_loss':   float(profit_loss)  if profit_loss  else None,
        'session':       session or '',
        'notes':         notes   or '',
        'image_id':      image_id,
        'trade_date':    trade_date,
        'entry_time':    entry_time,
        'exit_time':     exit_time,
        'duration_mins': int(duration_mins) if duration_mins is not None else None,
        'utc_offset':    utc_offset,
        'created_at':    datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
    })
    return str(result.inserted_id)


def get_trades(user_id, limit=None, skip=0):
    db     = get_db()
    cursor = db.trades.find(
        {'user_id': user_id},
        sort=[('trade_date', DESCENDING), ('created_at', DESCENDING)]
    ).skip(skip)
    if limit:
        cursor = cursor.limit(limit)
    return [doc_to_dict(d) for d in cursor]


def get_trades_since(user_id, since_date):
    db     = get_db()
    cursor = db.trades.find(
        {'user_id': user_id, 'trade_date': {'$gte': since_date}},
        sort=[('trade_date', DESCENDING)]
    )
    return [doc_to_dict(d) for d in cursor]


def get_trade_by_id(trade_id, user_id):
    db = get_db()
    try:
        doc = db.trades.find_one({'_id': ObjectId(trade_id), 'user_id': user_id})
        return doc_to_dict(doc)
    except Exception:
        return None


def update_trade(trade_id, user_id, updates):
    db     = get_db()
    result = db.trades.update_one(
        {'_id': ObjectId(trade_id), 'user_id': user_id},
        {'$set': updates}
    )
    return result.modified_count > 0


def delete_trade_by_id(trade_id, user_id):
    """Delete a trade and return it (so caller can clean up image)."""
    trade = get_trade_by_id(trade_id, user_id)
    if trade:
        db = get_db()
        db.trades.delete_one({'_id': ObjectId(trade_id), 'user_id': user_id})
    return trade


def get_trade_by_image_id(image_id, user_id):
    db  = get_db()
    doc = db.trades.find_one({'image_id': image_id, 'user_id': user_id})
    return doc_to_dict(doc)


# ═══════════════════════════════════════════════
# IMAGES (GridFS)
# ═══════════════════════════════════════════════

def save_image(file_obj, filename, user_id, trade_date, content_type='image/jpeg'):
    fs   = get_fs()
    data = file_obj.read()
    fid  = fs.put(
        data,
        filename=filename,
        content_type=content_type,
        metadata={'user_id': user_id, 'trade_date': trade_date}
    )
    return str(fid)


def get_image(image_id):
    fs = get_fs()
    try:
        f            = fs.get(ObjectId(image_id))
        data         = f.read()
        content_type = f.content_type or 'image/jpeg'
        return data, content_type
    except Exception:
        return None, None


def delete_image(image_id):
    if not image_id:
        return
    fs = get_fs()
    try:
        fs.delete(ObjectId(image_id))
    except Exception as e:
        print(f"[MongoDB] Error deleting image {image_id}: {e}")


def is_valid_image_id(value):
    if not value:
        return False
    return bool(re.fullmatch(r'[0-9a-fA-F]{24}', str(value)))