"""
Traders Vault - Admin Module
==============================
Admin dashboard — full access to all features, users, trades.
Only accessible to accounts with role='admin'.

To make your account admin, run this once in Python:
  from database import get_db
  from bson import ObjectId
  db = get_db()
  db.users.update_one({'email': 'your@email.com'}, {'$set': {'role': 'admin'}})
"""

from flask import (Blueprint, render_template, session, redirect,
                   url_for, flash, request, jsonify)
from database import get_db, get_user_by_id
from auth import login_required
import functools

admin_bp = Blueprint('admin', __name__)


# ─────────────────────────────────────────────
# Admin Required Decorator
# ─────────────────────────────────────────────
def admin_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            flash('Please log in.', 'warning')
            return redirect(url_for('auth.login'))
        user = get_user_by_id(session['user_id'])
        if not user or user.get('role') != 'admin':
            flash('Access denied. Admin only.', 'error')
            return redirect(url_for('journal.index'))
        return view(**kwargs)
    return wrapped_view


# ─────────────────────────────────────────────
# Admin Dashboard
# ─────────────────────────────────────────────
@admin_bp.route('/')
@admin_required
def index():
    db = get_db()

    # Stats
    total_users  = db.users.count_documents({})
    total_trades = db.trades.count_documents({})
    pro_users    = db.users.count_documents({'plan': 'medium'})
    elite_users  = db.users.count_documents({'plan': 'high'})
    free_users   = db.users.count_documents({'plan': 'normal'})

    # Recent users
    recent_users = list(db.users.find(
        {}, {'password': 0}
    ).sort('created_at', -1).limit(20))

    for u in recent_users:
        u['id'] = str(u.pop('_id'))

    # Revenue estimate
    revenue = (pro_users * 24.99) + (elite_users * 59.99)

    stats = {
        'total_users':  total_users,
        'total_trades': total_trades,
        'pro_users':    pro_users,
        'elite_users':  elite_users,
        'free_users':   free_users,
        'revenue':      round(revenue, 2),
    }

    return render_template('admin.html', stats=stats, users=recent_users)


# ─────────────────────────────────────────────
# View All Users
# ─────────────────────────────────────────────
@admin_bp.route('/users')
@admin_required
def users():
    db    = get_db()
    page  = int(request.args.get('page', 1))
    limit = 50
    skip  = (page - 1) * limit

    all_users = list(db.users.find(
        {}, {'password': 0}
    ).sort('created_at', -1).skip(skip).limit(limit))

    for u in all_users:
        u['id'] = str(u.pop('_id'))
        # Count their trades
        u['trade_count'] = db.trades.count_documents({'user_id': u['id']})

    total = db.users.count_documents({})
    return render_template('admin_users.html', users=all_users,
                           page=page, total=total, limit=limit)


# ─────────────────────────────────────────────
# Update User Plan
# ─────────────────────────────────────────────
@admin_bp.route('/users/<user_id>/plan', methods=['POST'])
@admin_required
def update_plan(user_id):
    plan = request.form.get('plan', 'normal')
    if plan not in ('normal', 'medium', 'high', 'admin'):
        flash('Invalid plan.', 'error')
        return redirect(url_for('admin.users'))

    db = get_db()
    from bson import ObjectId
    db.users.update_one(
        {'_id': ObjectId(user_id)},
        {'$set': {'plan': plan}}
    )
    flash(f'User plan updated to {plan}.', 'success')
    return redirect(url_for('admin.users'))


# ─────────────────────────────────────────────
# Update User Role (make admin)
# ─────────────────────────────────────────────
@admin_bp.route('/users/<user_id>/role', methods=['POST'])
@admin_required
def update_role(user_id):
    role = request.form.get('role', 'user')
    if role not in ('user', 'admin'):
        flash('Invalid role.', 'error')
        return redirect(url_for('admin.users'))

    db = get_db()
    from bson import ObjectId
    db.users.update_one(
        {'_id': ObjectId(user_id)},
        {'$set': {'role': role}}
    )
    flash(f'User role updated to {role}.', 'success')
    return redirect(url_for('admin.users'))


# ─────────────────────────────────────────────
# Delete User
# ─────────────────────────────────────────────
@admin_bp.route('/users/<user_id>/delete', methods=['POST'])
@admin_required
def delete_user(user_id):
    db = get_db()
    from bson import ObjectId
    # Delete all their trades too
    db.trades.delete_many({'user_id': user_id})
    db.users.delete_one({'_id': ObjectId(user_id)})
    flash('User and all their trades deleted.', 'info')
    return redirect(url_for('admin.users'))


# ─────────────────────────────────────────────
# View All Trades
# ─────────────────────────────────────────────
@admin_bp.route('/trades')
@admin_required
def trades():
    db    = get_db()
    page  = int(request.args.get('page', 1))
    limit = 50
    skip  = (page - 1) * limit

    all_trades = list(db.trades.find(
        {}
    ).sort('created_at', -1).skip(skip).limit(limit))

    for t in all_trades:
        t['id'] = str(t.pop('_id'))

    total = db.trades.count_documents({})
    return render_template('admin_trades.html', trades=all_trades,
                           page=page, total=total, limit=limit)


# ─────────────────────────────────────────────
# Admin API — Stats
# ─────────────────────────────────────────────
@admin_bp.route('/api/stats')
@admin_required
def api_stats():
    db = get_db()
    return jsonify({
        'total_users':  db.users.count_documents({}),
        'total_trades': db.trades.count_documents({}),
        'pro_users':    db.users.count_documents({'plan': 'medium'}),
        'elite_users':  db.users.count_documents({'plan': 'high'}),
        'free_users':   db.users.count_documents({'plan': 'normal'}),
    })