"""
Traders Vault - Price Alerts Module
=====================================
Users set price alerts. Background scheduler checks prices
every 60 seconds and sends email when price is reached.
"""

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from auth import login_required, get_current_user
from database import get_db
from email_module import send_alert_email
import os, requests
from datetime import datetime
from bson import ObjectId

alerts_bp = Blueprint('alerts', __name__)

TWELVE_DATA_KEY = os.environ.get('TWELVE_DATA_API_KEY', 'bb031e51e28041a1bc316ad2ef7699e7')

ALERT_PAIRS = [
    'EUR/USD','GBP/USD','USD/JPY','USD/CHF','AUD/USD','NZD/USD','USD/CAD',
    'GBP/JPY','EUR/JPY','XAU/USD','XAG/USD','BTC/USD','ETH/USD','NDX','SPX'
]


def get_live_price(symbol):
    """Fetch current price from Twelve Data."""
    try:
        url    = 'https://api.twelvedata.com/price'
        params = {'symbol': symbol, 'apikey': TWELVE_DATA_KEY}
        resp   = requests.get(url, params=params, timeout=5)
        data   = resp.json()
        return float(data['price']) if 'price' in data else None
    except:
        return None


def check_all_alerts(app):
    """Called by scheduler every 60s. Checks all active alerts."""
    with app.app_context():
        try:
            db     = get_db()
            alerts = list(db.alerts.find({'status': 'active'}))
            print(f"[Alerts] Checking {len(alerts)} active alerts...")

            # Group by symbol to minimize API calls
            symbol_map = {}
            for alert in alerts:
                sym = alert['pair']
                if sym not in symbol_map:
                    symbol_map[sym] = []
                symbol_map[sym].append(alert)

            for symbol, sym_alerts in symbol_map.items():
                price = get_live_price(symbol)
                if price is None:
                    continue

                for alert in sym_alerts:
                    triggered = False
                    condition = alert.get('condition', 'above')

                    if condition == 'above' and price >= alert['target_price']:
                        triggered = True
                    elif condition == 'below' and price <= alert['target_price']:
                        triggered = True

                    if triggered:
                        # Send email
                        user = db.users.find_one({'_id': ObjectId(alert['user_id'])})
                        if user and user.get('email'):
                            send_alert_email(
                                to_email   = user['email'],
                                username   = user['username'],
                                pair       = symbol,
                                price      = price,
                                target     = alert['target_price'],
                                condition  = condition,
                                message    = alert.get('message', ''),
                            )

                        # Mark as triggered
                        db.alerts.update_one(
                            {'_id': alert['_id']},
                            {'$set': {
                                'status':       'triggered',
                                'triggered_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
                                'triggered_price': price,
                            }}
                        )
                        print(f"[Alerts] ✓ Alert triggered: {symbol} @ {price}")

        except Exception as e:
            print(f"[Alerts] Error checking alerts: {e}")


# ─── Routes ──────────────────────────────────────────────────

@alerts_bp.route('/')
@login_required
def index():
    user_id = session['user_id']
    db      = get_db()
    alerts  = list(db.alerts.find({'user_id': user_id}).sort('created_at', -1))
    for a in alerts:
        a['id'] = str(a.pop('_id'))
    return render_template('alerts.html', alerts=alerts, pairs=ALERT_PAIRS)


@alerts_bp.route('/add', methods=['POST'])
@login_required
def add_alert():
    user_id      = session['user_id']
    pair         = request.form.get('pair', '')
    target_price = request.form.get('target_price', '')
    condition    = request.form.get('condition', 'above')
    message      = request.form.get('message', '')

    if not pair or not target_price:
        flash('Pair and target price are required.', 'error')
        return redirect(url_for('alerts.index'))

    try:
        target_price = float(target_price)
    except:
        flash('Invalid price.', 'error')
        return redirect(url_for('alerts.index'))

    db = get_db()
    db.alerts.insert_one({
        'user_id':      user_id,
        'pair':         pair,
        'target_price': target_price,
        'condition':    condition,
        'message':      message,
        'status':       'active',
        'created_at':   datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        'triggered_at': None,
        'triggered_price': None,
    })

    flash(f'Alert set — you\'ll get an email when {pair} goes {condition} {target_price}', 'success')
    return redirect(url_for('alerts.index'))


@alerts_bp.route('/delete/<alert_id>', methods=['POST'])
@login_required
def delete_alert(alert_id):
    user_id = session['user_id']
    db      = get_db()
    db.alerts.delete_one({'_id': ObjectId(alert_id), 'user_id': user_id})
    flash('Alert deleted.', 'info')
    return redirect(url_for('alerts.index'))


@alerts_bp.route('/toggle/<alert_id>', methods=['POST'])
@login_required
def toggle_alert(alert_id):
    user_id = session['user_id']
    db      = get_db()
    alert   = db.alerts.find_one({'_id': ObjectId(alert_id), 'user_id': user_id})
    if alert:
        new_status = 'paused' if alert['status'] == 'active' else 'active'
        db.alerts.update_one({'_id': ObjectId(alert_id)}, {'$set': {'status': new_status}})
    return redirect(url_for('alerts.index'))


@alerts_bp.route('/api/active')
@login_required
def api_active():
    """Returns count of active alerts for notification badge."""
    user_id = session['user_id']
    db      = get_db()
    count   = db.alerts.count_documents({'user_id': user_id, 'status': 'active'})
    return jsonify({'active': count})