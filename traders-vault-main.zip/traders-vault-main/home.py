"""
Traders Vault - Home Module
"""
from flask import Blueprint, render_template, session
from auth import get_current_user

home_bp = Blueprint('home', __name__)

@home_bp.route('/')
def index():
    user = get_current_user() if 'user_id' in session else None
    return render_template('home.html', user=user)
