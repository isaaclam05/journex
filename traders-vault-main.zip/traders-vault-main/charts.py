"""
Traders Vault - Charts Module
================================
Live candlestick charts powered by Twelve Data API
and TradingView Lightweight Charts library.
"""

from flask import Blueprint, render_template, jsonify, request, session
from auth import login_required
import os, requests
from datetime import datetime

charts_bp = Blueprint('charts', __name__)

TWELVE_DATA_KEY = os.environ.get('TWELVE_DATA_API_KEY', 'bb031e51e28041a1bc316ad2ef7699e7')

PAIRS = {
    'Forex':  ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'NZD/USD', 'USD/CAD', 'GBP/JPY', 'EUR/JPY'],
    'Metals': ['XAU/USD', 'XAG/USD'],
    'Crypto': ['BTC/USD', 'ETH/USD'],
    'Index':  ['NDX', 'SPX', 'DJI'],
}

TIMEFRAMES = [
    {'label': 'M1',  'value': '1min'},
    {'label': 'M5',  'value': '5min'},
    {'label': 'M15', 'value': '15min'},
    {'label': 'M30', 'value': '30min'},
    {'label': 'H1',  'value': '1h'},
    {'label': 'H4',  'value': '4h'},
    {'label': 'D1',  'value': '1day'},
    {'label': 'W1',  'value': '1week'},
]


@charts_bp.route('/')
@login_required
def index():
    return render_template('charts.html', pairs=PAIRS, timeframes=TIMEFRAMES)


@charts_bp.route('/api/candles')
@login_required
def get_candles():
    symbol     = request.args.get('symbol', 'EUR/USD')
    interval   = request.args.get('interval', '1day')
    outputsize = request.args.get('outputsize', '100')

    try:
        url    = 'https://api.twelvedata.com/time_series'
        params = {
            'symbol':     symbol,
            'interval':   interval,
            'outputsize': outputsize,
            'apikey':     TWELVE_DATA_KEY,
            'format':     'JSON',
            'timezone':   'UTC',
        }
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()

        if data.get('status') == 'error' or 'values' not in data:
            return jsonify({'error': data.get('message', 'API error')}), 400

        candles = []
        for v in reversed(data['values']):
            dt_str = v['datetime']
            # Always use unix timestamp for consistency
            try:
                if len(dt_str) == 10:  # date only: 2024-01-01
                    d = datetime.strptime(dt_str, '%Y-%m-%d')
                else:
                    d = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
                ts = int(d.timestamp())
            except:
                ts = 0

            candles.append({
                'time':  ts,
                'open':  float(v['open']),
                'high':  float(v['high']),
                'low':   float(v['low']),
                'close': float(v['close']),
            })

        return jsonify({
            'candles':  candles,
            'symbol':   symbol,
            'interval': interval,
            'count':    len(candles)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@charts_bp.route('/api/price')
@login_required
def get_price():
    symbol = request.args.get('symbol', 'EUR/USD')
    try:
        url    = 'https://api.twelvedata.com/price'
        params = {'symbol': symbol, 'apikey': TWELVE_DATA_KEY}
        resp   = requests.get(url, params=params, timeout=5)
        return jsonify(resp.json())
    except Exception as e:
        return jsonify({'error': str(e)}), 500