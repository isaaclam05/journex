"""
Journex - Main Application Entry Point
============================================
Flask-based trading journal platform.
"""

from flask import Flask, render_template, redirect, url_for, flash, request, session
from database import init_db
from auth import auth_bp
from journal import journal_bp
from analytics import analytics_bp
from news import news_bp
from plans import plans_bp
from home import home_bp
from calendar_module import calendar_bp
from admin import admin_bp
from dashboard import dashboard_bp
from legal import legal_bp
from charts import charts_bp
from alerts import alerts_bp, check_all_alerts
from economic_calendar import economic_calendar_bp
from risk import risk_bp
from planner import planner_bp
from habits import habits_bp
from economic_dashboard import economic_dashboard_bp
import os

app = Flask(__name__)

# ─── Secret key ──────────────────────────────────────────────
app.secret_key = os.environ.get('SECRET_KEY', 'journex-dev-secret-change-in-prod')

# ─── File Uploads ────────────────────────────────────────────
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
app.config['UPLOAD_FOLDER']      = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB

# ─── Site Settings ───────────────────────────────────────────
app.config['SITE_NAME']   = 'Journex'
app.config['SITE_DOMAIN'] = os.environ.get('SITE_DOMAIN', 'http://localhost:5000')
app.config['SITE_EMAIL']  = os.environ.get('SITE_EMAIL', 'support@journex.app')

# ─── Register Blueprints ─────────────────────────────────────
app.register_blueprint(home_bp)
app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
app.register_blueprint(auth_bp,      url_prefix='/auth')
app.register_blueprint(journal_bp,   url_prefix='/journal')
app.register_blueprint(analytics_bp, url_prefix='/analytics')
app.register_blueprint(news_bp,      url_prefix='/news')
app.register_blueprint(plans_bp,     url_prefix='/plans')
app.register_blueprint(calendar_bp,  url_prefix='/calendar')
app.register_blueprint(admin_bp,     url_prefix='/admin')
app.register_blueprint(legal_bp,     url_prefix='/legal')
app.register_blueprint(charts_bp,    url_prefix='/charts')
app.register_blueprint(alerts_bp,            url_prefix='/alerts')
app.register_blueprint(economic_calendar_bp, url_prefix='/calendar-events')
app.register_blueprint(risk_bp,              url_prefix='/risk')
app.register_blueprint(planner_bp,           url_prefix='/planner')
app.register_blueprint(habits_bp,               url_prefix='/habits')
app.register_blueprint(economic_dashboard_bp,    url_prefix='/economic-dashboard')

# ─── PWA Routes ──────────────────────────────────────────────
@app.route('/manifest.json')
def manifest():
    from flask import send_from_directory
    return send_from_directory('static', 'manifest.json',
                               mimetype='application/manifest+json')

@app.route('/service-worker.js')
def service_worker():
    from flask import send_from_directory
    return send_from_directory('static', 'service-worker.js',
                               mimetype='application/javascript')

@app.route('/offline')
def offline():
    return render_template('offline.html')

# ─── Error Handlers ──────────────────────────────────────────
@app.errorhandler(413)
def too_large(e):
    flash('File too large. Max 100MB.', 'error')
    return redirect(request.referrer or url_for('journal.index'))

@app.errorhandler(404)
def not_found(e):
    if session.get('user_id'):
        return redirect(url_for('dashboard.index'))
    return redirect(url_for('home.index'))

@app.errorhandler(500)
def server_error(e):
    flash('Something went wrong. Please try again.', 'error')
    return redirect(request.referrer or url_for('home.index'))

# ─── Init ────────────────────────────────────────────────────
with app.app_context():
    init_db()
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ─── Background Scheduler ────────────────────────────────────
from apscheduler.schedulers.background import BackgroundScheduler
scheduler = BackgroundScheduler()
scheduler.add_job(func=check_all_alerts, args=[app], trigger='interval', seconds=60, id='price_alerts')

def send_weekly_emails(app):
    """Runs every Monday 8am UTC — sends weekly performance emails to all users."""
    with app.app_context():
        try:
            from database import get_db, get_trades
            from email_module import send_weekly_performance_email
            from datetime import datetime, timedelta
            db = get_db()
            users = list(db.users.find({'plan': {'$ne': 'normal'}}))
            week_ago = (datetime.utcnow() - timedelta(days=7)).strftime('%Y-%m-%d')
            for user in users:
                try:
                    uid    = str(user['_id'])
                    trades = get_trades(uid)
                    week_t = [t for t in trades if t.get('profit_loss') is not None and t.get('trade_date','') >= week_ago]
                    if not week_t: continue
                    wins   = [t for t in week_t if t['profit_loss'] > 0]
                    pairs  = {}
                    for t in week_t:
                        p = t.get('pair','?')
                        pairs[p] = pairs.get(p,0) + t['profit_loss']
                    rr_vals = [t['rr_ratio'] for t in week_t if t.get('rr_ratio')]
                    stats = {
                        'week_pl':      round(sum(t['profit_loss'] for t in week_t), 2),
                        'win_rate':     round(len(wins)/len(week_t)*100, 1) if week_t else 0,
                        'total_trades': len(week_t),
                        'wins':         len(wins),
                        'losses':       len(week_t) - len(wins),
                        'avg_rr':       round(sum(rr_vals)/len(rr_vals),2) if rr_vals else 0,
                        'best_pair':    max(pairs, key=pairs.get) if pairs else 'N/A',
                        'best_session': 'N/A',
                    }
                    send_weekly_performance_email(user['email'], user['username'], stats)
                    print(f"[Weekly] Sent to {user['email']}")
                except Exception as e:
                    print(f"[Weekly] Error for {user.get('email')}: {e}")
        except Exception as e:
            print(f"[Weekly] Job error: {e}")

scheduler.add_job(func=send_weekly_emails, args=[app], trigger='cron',
                  day_of_week='mon', hour=8, minute=0, id='weekly_emails')
scheduler.start()
import atexit
atexit.register(lambda: scheduler.shutdown())

if __name__ == '__main__':
    port  = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV', 'development') == 'development'
    app.run(host='0.0.0.0', port=port, debug=debug)