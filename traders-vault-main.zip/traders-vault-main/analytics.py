"""
Traders Vault - Analytics Module
===================================
Trading performance analytics: win rate, RR, P&L, best pairs, sessions.
"""

from flask import Blueprint, render_template, request, jsonify, session, Response
from database import get_db, get_trades
from auth import login_required, get_current_user
from datetime import datetime, timedelta

analytics_bp = Blueprint('analytics', __name__)


def _get_dow_stats(closed_trades):
    dow_names = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
    dow_data  = {i: {'trades':0,'wins':0,'pl':0.0} for i in range(7)}
    for t in closed_trades:
        d = t.get('trade_date','')
        if d:
            try:
                dow = datetime.strptime(d,'%Y-%m-%d').weekday()
                dow_data[dow]['trades'] += 1
                dow_data[dow]['pl']      = round(dow_data[dow]['pl'] + t['profit_loss'], 2)
                if t['profit_loss'] > 0:
                    dow_data[dow]['wins'] += 1
            except: pass
    result = []
    for i in range(7):
        d  = dow_data[i]
        wr = round(d['wins']/d['trades']*100,1) if d['trades'] > 0 else 0
        result.append({'day':dow_names[i],'short':dow_names[i][:3],
                       'trades':d['trades'],'win_rate':wr,'pl':d['pl']})
    return result


def get_analytics_data(user_id, timeframe='all'):
    now    = datetime.utcnow()
    cutoff = None
    if timeframe == 'daily':
        cutoff = now.strftime('%Y-%m-%d')
    elif timeframe == 'weekly':
        cutoff = (now - timedelta(days=7)).strftime('%Y-%m-%d')
    elif timeframe == 'monthly':
        cutoff = (now - timedelta(days=30)).strftime('%Y-%m-%d')
    elif timeframe == 'yearly':
        cutoff = (now - timedelta(days=365)).strftime('%Y-%m-%d')

    all_trades = get_trades(user_id)
    trades = [t for t in all_trades if t.get('trade_date','') >= cutoff] if cutoff else all_trades

    if not trades:
        return {
            'total_trades':0,'win_rate':0,'avg_rr':0,'total_pl':0,
            'wins':0,'losses':0,'best_pair':'N/A','worst_pair':'N/A',
            'best_session':'N/A','pair_stats':[],'session_stats':[],
            'monthly_pl':[],'daily_pl':[],'direction_stats':{'buys':0,'sells':0},
            'dow_stats':[]
        }

    total   = len(trades)
    with_pl = [t for t in trades if t.get('profit_loss') is not None]
    wins    = [t for t in with_pl if t['profit_loss'] > 0]
    losses  = [t for t in with_pl if t['profit_loss'] < 0]

    win_rate  = round(len(wins)/len(with_pl)*100,1) if with_pl else 0
    total_pl  = round(sum(t['profit_loss'] for t in with_pl),2) if with_pl else 0
    rr_values = [t['rr_ratio'] for t in trades if t.get('rr_ratio')]
    avg_rr    = round(sum(rr_values)/len(rr_values),2) if rr_values else 0

    # Pair stats
    pair_map = {}
    for t in with_pl:
        p = t.get('pair','Unknown')
        if p not in pair_map:
            pair_map[p] = {'pair':p,'trades':0,'pl':0,'wins':0}
        pair_map[p]['trades'] += 1
        pair_map[p]['pl']     += t['profit_loss']
        if t['profit_loss'] > 0:
            pair_map[p]['wins'] += 1
    pair_stats = sorted(pair_map.values(), key=lambda x: x['pl'], reverse=True)
    for ps in pair_stats:
        ps['pl']       = round(ps['pl'],2)
        ps['win_rate'] = round(ps['wins']/ps['trades']*100,1) if ps['trades'] else 0
    best_pair  = pair_stats[0]['pair']  if pair_stats else 'N/A'
    worst_pair = pair_stats[-1]['pair'] if pair_stats else 'N/A'

    # Session stats
    sess_map = {}
    for t in trades:
        s = t.get('session') or 'Unknown'
        if s not in sess_map:
            sess_map[s] = {'session':s,'trades':0,'pl':0,'wins':0}
        sess_map[s]['trades'] += 1
        if t.get('profit_loss') is not None:
            sess_map[s]['pl'] += t['profit_loss']
            if t['profit_loss'] > 0:
                sess_map[s]['wins'] += 1
    session_stats = sorted(sess_map.values(), key=lambda x: x['pl'], reverse=True)
    for ss in session_stats:
        ss['pl']       = round(ss['pl'],2)
        ss['win_rate'] = round(ss['wins']/ss['trades']*100,1) if ss['trades'] else 0
    best_session = session_stats[0]['session'] if session_stats else 'N/A'

    # Monthly P&L
    monthly = {}
    for t in with_pl:
        m = t.get('trade_date','')[:7] or 'Unknown'
        monthly[m] = round(monthly.get(m,0)+t['profit_loss'],2)
    monthly_pl = [{'month':k,'pl':v} for k,v in sorted(monthly.items())]

    # Daily P&L last 30 days
    daily = {}
    for t in with_pl:
        d = t.get('trade_date','Unknown')
        daily[d] = round(daily.get(d,0)+t['profit_loss'],2)
    daily_pl = [{'date':k,'pl':v} for k,v in sorted(daily.items())[-30:]]

    buys  = [t for t in trades if t.get('direction','').upper()=='BUY']
    sells = [t for t in trades if t.get('direction','').upper()=='SELL']

    return {
        'total_trades':total,'win_rate':win_rate,'avg_rr':avg_rr,
        'total_pl':total_pl,'wins':len(wins),'losses':len(losses),
        'best_pair':best_pair,'worst_pair':worst_pair,'best_session':best_session,
        'pair_stats':pair_stats,'session_stats':session_stats,
        'monthly_pl':monthly_pl,'daily_pl':daily_pl,
        'direction_stats':{'buys':len(buys),'sells':len(sells)},
        'dow_stats': _get_dow_stats(with_pl),
    }


def get_trade_stats(user_id, timeframe='all'):
    """Advanced trade statistics for the stats page."""
    now    = datetime.utcnow()
    cutoff = None
    if timeframe == 'weekly':
        cutoff = (now - timedelta(days=7)).strftime('%Y-%m-%d')
    elif timeframe == 'monthly':
        cutoff = (now - timedelta(days=30)).strftime('%Y-%m-%d')
    elif timeframe == 'yearly':
        cutoff = (now - timedelta(days=365)).strftime('%Y-%m-%d')

    all_trades = get_trades(user_id)
    trades = [t for t in all_trades if t.get('trade_date','') >= cutoff] if cutoff else all_trades
    with_pl = sorted([t for t in trades if t.get('profit_loss') is not None],
                     key=lambda x: x.get('trade_date',''))
    wins   = [t for t in with_pl if t['profit_loss'] > 0]
    losses = [t for t in with_pl if t['profit_loss'] < 0]

    if not with_pl:
        return {'total_trades':0,'wins':0,'losses':0,'win_rate':0,
                'total_pl':0,'profit_factor':0,'avg_rr':0,
                'max_win_streak':0,'max_loss_streak':0,'max_drawdown':0,
                'avg_win':0,'avg_loss':0,'expectancy':0,
                'largest_win':0,'largest_loss':0,'trading_days':0,
                'dow_stats':[],'pair_stats':[],'pl_distribution':[]}

    # Streaks
    max_win_streak = cur_w = 0
    max_loss_streak = cur_l = 0
    for t in with_pl:
        if t['profit_loss'] > 0:
            cur_w += 1; cur_l = 0
            max_win_streak = max(max_win_streak, cur_w)
        else:
            cur_l += 1; cur_w = 0
            max_loss_streak = max(max_loss_streak, cur_l)

    # Max drawdown
    peak = running = 0
    max_drawdown = 0
    for t in with_pl:
        running += t['profit_loss']
        if running > peak: peak = running
        dd = peak - running
        if dd > max_drawdown: max_drawdown = round(dd, 2)

    # Avg win/loss
    avg_win  = round(sum(t['profit_loss'] for t in wins)/len(wins),2)   if wins   else 0
    avg_loss = round(abs(sum(t['profit_loss'] for t in losses)/len(losses)),2) if losses else 0

    # Expectancy
    win_rate    = len(wins)/len(with_pl) if with_pl else 0
    expectancy  = round(win_rate*avg_win - (1-win_rate)*avg_loss, 2)

    # Profit factor
    gross_profit = sum(t['profit_loss'] for t in wins)
    gross_loss   = abs(sum(t['profit_loss'] for t in losses))
    profit_factor = round(gross_profit/gross_loss,2) if gross_loss > 0 else 0

    # RR
    rr_vals = [t['rr_ratio'] for t in trades if t.get('rr_ratio')]
    avg_rr  = round(sum(rr_vals)/len(rr_vals),2) if rr_vals else 0

    # P&L distribution buckets
    pls = [t['profit_loss'] for t in with_pl]
    if pls:
        mn, mx = min(pls), max(pls)
        step = max((mx-mn)/10, 1)
        buckets = {}
        for pl in pls:
            b = int((pl - mn) / step) * step + mn
            b = round(b, 2)
            buckets[b] = buckets.get(b, 0) + 1
        pl_dist = [{'label': f'${round(k,1)}', 'count': v, 'positive': k >= 0}
                   for k, v in sorted(buckets.items())]
    else:
        pl_dist = []

    # Pair stats
    pair_map = {}
    for t in with_pl:
        p = t.get('pair','?')
        if p not in pair_map:
            pair_map[p] = {'pair':p,'trades':0,'pl':0,'wins':0}
        pair_map[p]['trades'] += 1
        pair_map[p]['pl']     += t['profit_loss']
        if t['profit_loss'] > 0:
            pair_map[p]['wins'] += 1
    pair_stats = sorted(pair_map.values(), key=lambda x: x['pl'], reverse=True)
    for ps in pair_stats:
        ps['pl']       = round(ps['pl'],2)
        ps['win_rate'] = round(ps['wins']/ps['trades']*100,1)

    return {
        'total_trades':  len(trades),
        'wins':          len(wins),
        'losses':        len(losses),
        'win_rate':      round(win_rate*100,1),
        'total_pl':      round(sum(t['profit_loss'] for t in with_pl),2),
        'profit_factor': profit_factor,
        'avg_rr':        avg_rr,
        'max_win_streak':  max_win_streak,
        'max_loss_streak': max_loss_streak,
        'max_drawdown':    max_drawdown,
        'avg_win':         avg_win,
        'avg_loss':        avg_loss,
        'expectancy':      expectancy,
        'largest_win':     round(max((t['profit_loss'] for t in wins),   default=0),2),
        'largest_loss':    round(abs(min((t['profit_loss'] for t in losses), default=0)),2),
        'trading_days':    len(set(t.get('trade_date','') for t in with_pl)),
        'dow_stats':       _get_dow_stats(with_pl),
        'pair_stats':      pair_stats,
        'pl_distribution': pl_dist,
    }


@analytics_bp.route('/')
@login_required
def index():
    user_id   = session['user_id']
    timeframe = request.args.get('timeframe','all')
    data      = get_analytics_data(user_id, timeframe)
    user      = get_current_user()
    return render_template('analytics.html', data=data, timeframe=timeframe, user=user)


@analytics_bp.route('/stats')
@login_required
def trade_stats():
    user_id   = session['user_id']
    timeframe = request.args.get('timeframe','all')
    stats     = get_trade_stats(user_id, timeframe)
    user      = get_current_user()
    return render_template('trade_stats.html', stats=stats, timeframe=timeframe, user=user)


@analytics_bp.route('/api/data')
@login_required
def api_data():
    user_id   = session['user_id']
    timeframe = request.args.get('timeframe','all')
    return jsonify(get_analytics_data(user_id, timeframe))