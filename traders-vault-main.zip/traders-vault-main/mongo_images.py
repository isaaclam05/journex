"""
Traders Vault - MongoDB Image Storage
========================================
Stores and retrieves trade chart images using MongoDB GridFS.
GridFS splits large files into chunks and stores them in MongoDB,
so your images live in the database alongside your trade data.

Setup:
  1. Install MongoDB locally: https://www.mongodb.com/try/download/community
     OR use MongoDB Atlas (free cloud): https://www.mongodb.com/atlas
  2. pip install pymongo
  3. Set MONGO_URI in your .env file

.env example:
  MONGO_URI=mongodb://localhost:27017          ← local MongoDB
  MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/tradersvault  ← Atlas
"""

import os
from io import BytesIO

# ── MongoDB / GridFS imports ──────────────────────────────
try:
    from pymongo import MongoClient
    from gridfs import GridFS
    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    print("[WARN] pymongo not installed. Run: pip install pymongo")

# ── Connection (lazy — only connects when first used) ─────
_client = None
_db     = None
_fs     = None


def _get_fs():
    """Get or create a GridFS instance."""
    global _client, _db, _fs

    if not MONGO_AVAILABLE:
        raise RuntimeError("pymongo is not installed. Run: pip install pymongo")

    if _fs is None:
        mongo_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017')
        db_name   = os.environ.get('MONGO_DB_NAME', 'tradersvault')
        _client   = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
        _db       = _client[db_name]
        _fs       = GridFS(_db)
        print(f"[MongoDB] Connected to {db_name}")

    return _fs


def save_image(file_obj, filename, user_id, trade_date, content_type='image/jpeg'):
    """
    Save an uploaded image file to MongoDB GridFS.

    Args:
        file_obj    : file-like object (e.g. request.files['chart_image'])
        filename    : original filename (used for metadata)
        user_id     : int, the owner's user ID
        trade_date  : str, date of the trade (e.g. '2025-01-15')
        content_type: MIME type of the image

    Returns:
        str : the GridFS file ID as a string (store this in SQLite trades.image_path)
        None: if save failed
    """
    try:
        fs = _get_fs()
        data = file_obj.read()
        file_id = fs.put(
            data,
            filename=filename,
            content_type=content_type,
            metadata={
                'user_id':    user_id,
                'trade_date': trade_date,
                'original':   filename,
            }
        )
        print(f"[MongoDB] Saved image {filename} → id={file_id}")
        return str(file_id)
    except Exception as e:
        print(f"[MongoDB] ERROR saving image: {e}")
        return None


def get_image(file_id_str):
    """
    Retrieve an image from MongoDB GridFS by its ID.

    Args:
        file_id_str: the string ID returned by save_image()

    Returns:
        tuple: (bytes, content_type) or (None, None) if not found
    """
    try:
        from bson import ObjectId
        fs      = _get_fs()
        file_id = ObjectId(file_id_str)
        if not fs.exists(file_id):
            return None, None
        grid_file    = fs.get(file_id)
        data         = grid_file.read()
        content_type = grid_file.content_type or 'image/jpeg'
        return data, content_type
    except Exception as e:
        print(f"[MongoDB] ERROR retrieving image {file_id_str}: {e}")
        return None, None


def delete_image(file_id_str):
    """
    Delete an image from MongoDB GridFS.

    Args:
        file_id_str: the string ID returned by save_image()
    """
    try:
        from bson import ObjectId
        fs = _get_fs()
        fs.delete(ObjectId(file_id_str))
        print(f"[MongoDB] Deleted image id={file_id_str}")
    except Exception as e:
        print(f"[MongoDB] ERROR deleting image {file_id_str}: {e}")


def is_mongo_image_id(value):
    """
    Returns True if the value looks like a MongoDB ObjectId (24-char hex string).
    Used to distinguish new MongoDB IDs from old local filenames.
    """
    if not value:
        return False
    import re
    return bool(re.fullmatch(r'[0-9a-fA-F]{24}', str(value)))


def mongo_available():
    """Returns True if pymongo is installed and MongoDB is reachable."""
    if not MONGO_AVAILABLE:
        return False
    try:
        _get_fs()
        return True
    except Exception:
        return False
