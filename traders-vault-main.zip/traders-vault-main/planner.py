"""
Traders Vault - Weekly Session Planner Module
===============================================
Users write their weekly trading plan before markets open.
Compare planned pairs/levels vs actual trades taken.
"""

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from auth import login_required, get_current_user
from database import get_db, get_trades
from bson import ObjectId
from datetime import datetime, timedelta

planner_bp = Blueprint('planner', __name__)


def get_week_start():
    """Get Monday of the current week."""
    now   = datetime.utcnow()
    start = now - timedelta(days=now.weekday())
    return start.strftime('%Y-%m-%d')


def get_current_plan(user_id):
    db       = get_db()
    week_key = get_week_start()
    plan     = db.weekly_plans.find_one({'user_id': user_id, 'week': week_key})
    if plan:
        plan['id'] = str(plan.pop('_id'))
    return plan


def get_week_trades(user_id):
    """Get trades from this week."""
    week_start = get_week_start()
    trades     = get_trades(user_id)
    return [t for t in trades if t.get('trade_date', '') >= week_start]


@planner_bp.route('/')
@login_required
def index():
    user         = get_current_user()
    plan         = get_current_plan(session['user_id'])
    week_trades  = get_week_trades(session['user_id'])
    week_start   = get_week_start()

    # Week stats
    closed  = [t for t in week_trades if t.get('profit_loss') is not None]
    week_pl = round(sum(t['profit_loss'] for t in closed), 2) if closed else 0
    week_wr = round(len([t for t in closed if t['profit_loss'] > 0]) / len(closed) * 100, 1) if closed else 0

    return render_template('planner.html',
                           user=user, plan=plan,
                           week_trades=week_trades,
                           week_start=week_start,
                           week_pl=week_pl,
                           week_wr=week_wr)


@planner_bp.route('/save', methods=['POST'])
@login_required
def save():
    user_id  = session['user_id']
    week_key = get_week_start()
    db       = get_db()

    plan_data = {
        'user_id':    user_id,
        'week':       week_key,
        'pairs':      request.form.get('pairs', ''),
        'bias':       request.form.get('bias', ''),
        'key_levels': request.form.get('key_levels', ''),
        'news_events':request.form.get('news_events', ''),
        'daily_target': request.form.get('daily_target', ''),
        'max_trades': request.form.get('max_trades', ''),
        'notes':      request.form.get('notes', ''),
        'rules':      request.form.get('rules', ''),
        'updated_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
    }

    db.weekly_plans.update_one(
        {'user_id': user_id, 'week': week_key},
        {'$set': plan_data},
        upsert=True
    )
    flash('Weekly plan saved!', 'success')
    return redirect(url_for('planner.index'))


@planner_bp.route('/history')
@login_required
def history():
    user_id = session['user_id']
    db      = get_db()
    plans   = list(db.weekly_plans.find({'user_id': user_id}).sort('week', -1).limit(12))
    for p in plans:
        p['id'] = str(p.pop('_id'))
    user = get_current_user()
    return render_template('planner_history.html', plans=plans, user=user)
