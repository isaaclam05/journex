"""
Journex - Economic Dashboard
==============================
Live forex rates, stock indices, commodities, crypto,
economic indicators, fear & greed, market breadth.
All free data sources — no paid API keys needed.
"""

from flask import Blueprint, render_template, jsonify
from auth import login_required, get_current_user
import urllib.request
import json
from datetime import datetime

economic_dashboard_bp = Blueprint('economic_dashboard', __name__)

# ─── Free Data Sources ───────────────────────────────────────

def fetch_forex_rates():
    """Free forex rates from exchangerate-api (no key needed for basic)."""
    try:
        url = 'https://open.er-api.com/v6/latest/USD'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode())
        rates = data.get('rates', {})
        pairs = {
            'EUR/USD': round(1 / rates.get('EUR', 1), 5),
            'GBP/USD': round(1 / rates.get('GBP', 1), 5),
            'USD/JPY': round(rates.get('JPY', 0), 3),
            'USD/CHF': round(rates.get('CHF', 0), 5),
            'AUD/USD': round(1 / rates.get('AUD', 1), 5),
            'NZD/USD': round(1 / rates.get('NZD', 1), 5),
            'USD/CAD': round(rates.get('CAD', 0), 5),
            'EUR/GBP': round(rates.get('GBP', 1) / rates.get('EUR', 1), 5),
            'EUR/JPY': round(rates.get('JPY', 1) / rates.get('EUR', 1), 3),
            'GBP/JPY': round(rates.get('JPY', 1) / rates.get('GBP', 1), 3),
            'USD/SGD': round(rates.get('SGD', 0), 5),
            'USD/CNY': round(rates.get('CNY', 0), 4),
        }
        return {'pairs': pairs, 'updated': datetime.utcnow().strftime('%H:%M UTC')}
    except Exception as e:
        print(f"[EconDash] Forex error: {e}")
        return {'pairs': {}, 'updated': 'unavailable'}


def fetch_crypto():
    """Free crypto prices from CoinGecko (no key needed)."""
    try:
        url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,binancecoin,ripple,cardano&vs_currencies=usd&include_24hr_change=true'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode())
        result = []
        symbols = {
            'bitcoin': 'BTC', 'ethereum': 'ETH', 'solana': 'SOL',
            'binancecoin': 'BNB', 'ripple': 'XRP', 'cardano': 'ADA'
        }
        for coin_id, symbol in symbols.items():
            if coin_id in data:
                d = data[coin_id]
                result.append({
                    'symbol':  symbol,
                    'price':   d.get('usd', 0),
                    'change':  round(d.get('usd_24h_change', 0), 2),
                })
        return result
    except Exception as e:
        print(f"[EconDash] Crypto error: {e}")
        return []


def fetch_commodities():
    """Commodity prices via Yahoo Finance (yfinance)."""
    try:
        import yfinance as yf
        symbols = {
            'GC=F':  ('Gold',        'XAU/USD', 'oz'),
            'SI=F':  ('Silver',      'XAG/USD', 'oz'),
            'CL=F':  ('Crude Oil',   'WTI',     'bbl'),
            'BZ=F':  ('Brent Oil',   'Brent',   'bbl'),
            'NG=F':  ('Natural Gas', 'Nat Gas', 'MMBtu'),
            'HG=F':  ('Copper',      'Copper',  'lb'),
        }
        result = []
        for ticker, (name, label, unit) in symbols.items():
            try:
                t    = yf.Ticker(ticker)
                hist = t.history(period='2d')
                if hist.empty: continue
                price = round(float(hist['Close'].iloc[-1]), 2)
                prev  = round(float(hist['Close'].iloc[-2]), 2) if len(hist) > 1 else price
                chg   = round(((price - prev) / prev) * 100, 2) if prev else 0
                result.append({'name': name, 'label': label, 'price': price, 'change': chg, 'unit': unit})
            except: pass
        return result
    except Exception as e:
        print(f"[EconDash] Commodities error: {e}")
        return []


def fetch_indices():
    """Major stock indices via yfinance."""
    try:
        import yfinance as yf
        symbols = {
            '^GSPC':  ('S&P 500',      'USA'),
            '^DJI':   ('Dow Jones',    'USA'),
            '^IXIC':  ('NASDAQ',       'USA'),
            '^RUT':   ('Russell 2000', 'USA'),
            '^FTSE':  ('FTSE 100',     'UK'),
            '^GDAXI': ('DAX',          'DE'),
            '^N225':  ('Nikkei 225',   'JP'),
            '^HSI':   ('Hang Seng',    'HK'),
            '^STI':   ('STI',          'SG'),
            '^VIX':   ('VIX',          'Fear'),
        }
        result = []
        for ticker, (name, region) in symbols.items():
            try:
                t    = yf.Ticker(ticker)
                hist = t.history(period='2d')
                if hist.empty: continue
                price = round(float(hist['Close'].iloc[-1]), 2)
                prev  = round(float(hist['Close'].iloc[-2]), 2) if len(hist) > 1 else price
                chg   = round(((price - prev) / prev) * 100, 2) if prev else 0
                result.append({'name': name, 'region': region, 'price': price, 'change': chg, 'ticker': ticker})
            except: pass
        return result
    except Exception as e:
        print(f"[EconDash] Indices error: {e}")
        return []


def fetch_fear_greed():
    """CNN Fear & Greed index — free API."""
    try:
        url = 'https://fear-and-greed-index.p.rapidapi.com/v1/fgi'
        # Fallback: calculate simple proxy from VIX
        import yfinance as yf
        vix = yf.Ticker('^VIX').history(period='1d')
        if not vix.empty:
            vix_val = float(vix['Close'].iloc[-1])
            # VIX < 12 = extreme greed, > 30 = extreme fear
            score = max(0, min(100, int(100 - (vix_val - 10) * 3)))
            if score >= 75:   label = 'Extreme Greed'
            elif score >= 55: label = 'Greed'
            elif score >= 45: label = 'Neutral'
            elif score >= 25: label = 'Fear'
            else:             label = 'Extreme Fear'
            return {'score': score, 'label': label, 'vix': round(vix_val, 2)}
    except: pass
    return {'score': 50, 'label': 'Neutral', 'vix': 0}


def get_market_status():
    """Check if major markets are currently open (UTC)."""
    now  = datetime.utcnow()
    hour = now.hour
    min_ = now.minute
    time_mins = hour * 60 + min_

    statuses = []
    # NYSE/NASDAQ: 13:30-20:00 UTC (Mon-Fri)
    if now.weekday() < 5:
        if 810 <= time_mins < 1200:
            statuses.append({'name': 'NYSE/NASDAQ', 'status': 'open',   'hours': '13:30-20:00 UTC'})
        else:
            statuses.append({'name': 'NYSE/NASDAQ', 'status': 'closed', 'hours': '13:30-20:00 UTC'})
    else:
        statuses.append({'name': 'NYSE/NASDAQ', 'status': 'weekend', 'hours': '13:30-20:00 UTC'})

    # London: 07:00-15:30 UTC
    if now.weekday() < 5:
        if 420 <= time_mins < 930:
            statuses.append({'name': 'London LSE', 'status': 'open',   'hours': '07:00-15:30 UTC'})
        else:
            statuses.append({'name': 'London LSE', 'status': 'closed', 'hours': '07:00-15:30 UTC'})

    # Tokyo: 00:00-06:00 UTC
    if now.weekday() < 5:
        if time_mins < 360 or time_mins >= 1380:
            statuses.append({'name': 'Tokyo TSE', 'status': 'open',   'hours': '00:00-06:00 UTC'})
        else:
            statuses.append({'name': 'Tokyo TSE', 'status': 'closed', 'hours': '00:00-06:00 UTC'})

    # Forex is 24/5
    if now.weekday() < 5:
        statuses.append({'name': 'Forex', 'status': 'open', 'hours': '24/5'})
    else:
        statuses.append({'name': 'Forex', 'status': 'weekend', 'hours': 'Closed weekends'})

    # Crypto is always open
    statuses.append({'name': 'Crypto', 'status': 'open', 'hours': '24/7'})

    return statuses


# ─── Routes ──────────────────────────────────────────────────

@economic_dashboard_bp.route('/')
@login_required
def index():
    user   = get_current_user()
    status = get_market_status()
    return render_template('economic_dashboard.html', user=user, market_status=status)


@economic_dashboard_bp.route('/api/forex')
@login_required
def api_forex():
    return jsonify(fetch_forex_rates())


@economic_dashboard_bp.route('/api/crypto')
@login_required
def api_crypto():
    return jsonify(fetch_crypto())


@economic_dashboard_bp.route('/api/commodities')
@login_required
def api_commodities():
    return jsonify(fetch_commodities())


@economic_dashboard_bp.route('/api/indices')
@login_required
def api_indices():
    return jsonify(fetch_indices())


@economic_dashboard_bp.route('/api/fear-greed')
@login_required
def api_fear_greed():
    return jsonify(fetch_fear_greed())


@economic_dashboard_bp.route('/api/all')
@login_required
def api_all():
    """Single endpoint — fetch everything at once."""
    return jsonify({
        'forex':       fetch_forex_rates(),
        'crypto':      fetch_crypto(),
        'commodities': fetch_commodities(),
        'indices':     fetch_indices(),
        'fear_greed':  fetch_fear_greed(),
        'status':      get_market_status(),
        'updated':     datetime.utcnow().strftime('%d %b %Y %H:%M UTC'),
    })