"""
Journex - Dashboard Module
==================================
Main dashboard page shown after login.
Shows: key stats, cumulative P&L chart, recent trades, mini calendar,
best/worst trades, account balance, day-of-week stats.
"""

from flask import Blueprint, render_template, session, request, jsonify
from database import get_db, get_trades
from auth import login_required, get_current_user
from datetime import datetime, timedelta
import calendar

dashboard_bp = Blueprint('dashboard', __name__)


def get_dashboard_data(user_id):
    trades = get_trades(user_id)

    if not trades:
        return {
            'total_trades': 0, 'wins': 0, 'losses': 0,
            'win_rate': 0, 'total_pl': 0, 'avg_rr': 0,
            'profit_factor': 0, 'best_pair': 'N/A',
            'recent_trades': [], 'cumulative_pl': [],
            'daily_pl_30': [], 'calendar_data': {},
            'monthly_stats': {'pl': 0, 'trades': 0, 'days': 0},
            'best_trade': None, 'worst_trade': None,
            'day_of_week_stats': [],
            'cal_grid': [], 'cal_month': '', 'cal_year': 0,
        }

    closed = [t for t in trades if t.get('profit_loss') is not None]
    wins   = [t for t in closed if t['profit_loss'] > 0]
    losses = [t for t in closed if t['profit_loss'] < 0]

    total_pl      = round(sum(t['profit_loss'] for t in closed), 2)
    win_rate      = round(len(wins) / len(closed) * 100, 1) if closed else 0
    rr_vals       = [t['rr_ratio'] for t in trades if t.get('rr_ratio')]
    avg_rr        = round(sum(rr_vals) / len(rr_vals), 2) if rr_vals else 0
    gross_profit  = sum(t['profit_loss'] for t in wins)
    gross_loss    = abs(sum(t['profit_loss'] for t in losses))
    profit_factor = round(gross_profit / gross_loss, 2) if gross_loss > 0 else (float('inf') if gross_profit > 0 else 0)

    # Best pair
    pair_pl  = {}
    for t in closed:
        p = t.get('pair', 'Unknown')
        pair_pl[p] = pair_pl.get(p, 0) + t['profit_loss']
    best_pair = max(pair_pl, key=pair_pl.get) if pair_pl else 'N/A'

    # Best & worst individual trades
    best_trade  = max(closed, key=lambda x: x['profit_loss']) if wins   else None
    worst_trade = min(closed, key=lambda x: x['profit_loss']) if losses else None

    # Cumulative P&L
    sorted_closed = sorted(closed, key=lambda x: x.get('trade_date', ''))
    cumulative = []
    running = 0
    for t in sorted_closed:
        running += t['profit_loss']
        cumulative.append({
            'date':     t.get('trade_date', ''),
            'pl':       round(running, 2),
            'trade_pl': round(t['profit_loss'], 2),
            'pair':     t.get('pair', ''),
        })

    # Daily P&L last 30 days
    now    = datetime.utcnow()
    cutoff = (now - timedelta(days=30)).strftime('%Y-%m-%d')
    day_map = {}
    for t in closed:
        d = t.get('trade_date', '')
        if d >= cutoff:
            day_map[d] = round(day_map.get(d, 0) + t['profit_loss'], 2)
    daily_30 = [{'date': k, 'pl': v} for k, v in sorted(day_map.items())]

    # Recent 8 trades
    recent = sorted(trades, key=lambda x: x.get('trade_date', ''), reverse=True)[:8]

    # Mini calendar — current month
    year = now.year; month = now.month
    cal_data = {}
    for t in closed:
        d = t.get('trade_date', '')
        if d:
            try:
                dt = datetime.strptime(d, '%Y-%m-%d')
                if dt.year == year and dt.month == month:
                    day = dt.day
                    cal_data[day] = {
                        'pl':     round(cal_data.get(day, {}).get('pl', 0) + t['profit_loss'], 2),
                        'trades': cal_data.get(day, {}).get('trades', 0) + 1
                    }
            except: pass

    # Monthly stats
    month_trades = [t for t in closed if t.get('trade_date', '').startswith(now.strftime('%Y-%m'))]
    monthly_stats = {
        'pl':     round(sum(t['profit_loss'] for t in month_trades), 2),
        'trades': len(month_trades),
        'days':   len(set(t.get('trade_date', '') for t in month_trades)),
    }

    # Day of week stats
    dow_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    dow_data  = {i: {'trades': 0, 'wins': 0, 'pl': 0.0} for i in range(7)}
    for t in closed:
        d = t.get('trade_date', '')
        if d:
            try:
                dow = datetime.strptime(d, '%Y-%m-%d').weekday()
                dow_data[dow]['trades'] += 1
                dow_data[dow]['pl']     = round(dow_data[dow]['pl'] + t['profit_loss'], 2)
                if t['profit_loss'] > 0:
                    dow_data[dow]['wins'] += 1
            except: pass

    dow_stats = []
    for i in range(7):
        d = dow_data[i]
        wr = round(d['wins'] / d['trades'] * 100, 1) if d['trades'] > 0 else 0
        dow_stats.append({
            'day': dow_names[i], 'short': dow_names[i][:3],
            'trades': d['trades'], 'wins': d['wins'],
            'win_rate': wr, 'pl': d['pl']
        })

    # Average hold time
    trades_with_duration = [t for t in trades if t.get('duration_mins') is not None and t['duration_mins'] > 0]
    if trades_with_duration:
        avg_mins = round(sum(t['duration_mins'] for t in trades_with_duration) / len(trades_with_duration))
        if avg_mins >= 60:
            avg_hold_time = f"{avg_mins // 60}h {avg_mins % 60}m"
        else:
            avg_hold_time = f"{avg_mins}m"
    else:
        avg_hold_time = 'N/A'

    return {
        'total_trades':      len(trades),
        'wins':              len(wins),
        'losses':            len(losses),
        'win_rate':          win_rate,
        'total_pl':          total_pl,
        'avg_rr':            avg_rr,
        'profit_factor':     profit_factor,
        'best_pair':         best_pair,
        'recent_trades':     recent,
        'cumulative_pl':     cumulative,
        'daily_pl_30':       daily_30,
        'calendar_data':     cal_data,
        'cal_grid':          calendar.monthcalendar(year, month),
        'cal_month':         calendar.month_name[month],
        'cal_year':          year,
        'monthly_stats':     monthly_stats,
        'best_trade':        best_trade,
        'worst_trade':       worst_trade,
        'day_of_week_stats': dow_stats,
        'avg_hold_time':     avg_hold_time,
    }


@dashboard_bp.route('/')
@login_required
def index():
    user = get_current_user()
    data = get_dashboard_data(user['id'])
    now  = datetime.utcnow()
    hour = (now.hour + 8) % 24  # Convert UTC to SGT (UTC+8)
    greeting = 'Good morning' if hour < 12 else 'Good afternoon' if hour < 17 else 'Good evening'
    heatmap   = get_heatmap_data(get_trades(user['id']))
    week_cmp  = get_week_comparison(get_trades(user['id']))

    # Consecutive loss check for banner
    from database import get_trades as _gt
    all_t   = _gt(user['id'])
    closed  = [t for t in all_t if t.get('profit_loss') is not None]
    sorted_c= sorted(closed, key=lambda x: x.get('trade_date',''), reverse=True)
    consec_losses = 0
    for t in sorted_c:
        if t['profit_loss'] < 0: consec_losses += 1
        else: break

    # Starting balance + % return
    starting_balance = float(user.get('starting_balance', 0))
    all_closed = [t for t in get_trades(user['id']) if t.get('profit_loss') is not None]
    total_pl   = round(sum(t['profit_loss'] for t in all_closed), 2)
    balance    = round(starting_balance + total_pl, 2) if starting_balance else 0
    pct_return = round((total_pl / starting_balance * 100), 1) if starting_balance > 0 else None

    return render_template('dashboard.html', data=data, user=user,
                           greeting=greeting, now=now,
                           heatmap=heatmap, week_cmp=week_cmp,
                           consec_losses=consec_losses,
                           starting_balance=starting_balance,
                           balance=balance, pct_return=pct_return,
                           total_pl=total_pl)


@dashboard_bp.route('/api/balance', methods=['POST'])
@login_required
def set_balance():
    """Save starting balance to MongoDB user record."""
    from database import get_db
    from bson import ObjectId
    balance = request.json.get('balance', 0)
    db = get_db()
    db.users.update_one({'_id': ObjectId(session['user_id'])}, {'$set': {'starting_balance': float(balance)}})
    return jsonify({'ok': True})


def get_heatmap_data(trades):
    """Hour-of-day profitability heatmap (0-23 UTC hours)."""
    closed = [t for t in trades if t.get('profit_loss') is not None]
    hours  = {i: {'trades': 0, 'wins': 0, 'pl': 0.0} for i in range(24)}
    for t in closed:
        et = t.get('entry_time', '')
        if et:
            try:
                h = int(et.split(':')[0])
                hours[h]['trades'] += 1
                hours[h]['pl']      = round(hours[h]['pl'] + t['profit_loss'], 2)
                if t['profit_loss'] > 0:
                    hours[h]['wins'] += 1
            except: pass
    result = []
    for h in range(24):
        d  = hours[h]
        wr = round(d['wins']/d['trades']*100,1) if d['trades'] else 0
        result.append({'hour': h, 'label': f'{h:02d}:00',
                       'trades': d['trades'], 'win_rate': wr, 'pl': d['pl']})
    return result


def get_week_comparison(trades):
    """Compare this week vs last week."""
    from datetime import timedelta
    now        = datetime.utcnow()
    week_start = (now - timedelta(days=now.weekday())).strftime('%Y-%m-%d')
    last_start = (now - timedelta(days=now.weekday()+7)).strftime('%Y-%m-%d')
    last_end   = (now - timedelta(days=now.weekday())).strftime('%Y-%m-%d')

    closed = [t for t in trades if t.get('profit_loss') is not None]
    this_w = [t for t in closed if t.get('trade_date','') >= week_start]
    last_w = [t for t in closed if last_start <= t.get('trade_date','') < last_end]

    def stats(ts):
        if not ts: return {'pl': 0, 'trades': 0, 'win_rate': 0}
        wins = [t for t in ts if t['profit_loss'] > 0]
        return {
            'pl':       round(sum(t['profit_loss'] for t in ts), 2),
            'trades':   len(ts),
            'win_rate': round(len(wins)/len(ts)*100,1) if ts else 0,
        }

    tw = stats(this_w)
    lw = stats(last_w)
    return {
        'this_week': tw, 'last_week': lw,
        'pl_diff':   round(tw['pl'] - lw['pl'], 2),
        'wr_diff':   round(tw['win_rate'] - lw['win_rate'], 1),
    }
