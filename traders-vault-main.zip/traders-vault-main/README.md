# ◈ TRADERS VAULT
### AI-Powered Trading Journal Platform

A professional-grade, full-stack trading journal built with **Flask + SQLite**.  
Dark fintech UI, analytics dashboards, market news, and a Stripe-ready billing system.

---

## 📁 Project Structure

```
tradersvault/
├── app.py              ← Main Flask entry point
├── database.py         ← SQLite setup & query helpers
├── auth.py             ← Registration, login, session auth
├── journal.py          ← Trade CRUD, import/export
├── analytics.py        ← Performance metrics & chart data
├── news.py             ← Market news (RSS feeds)
├── plans.py            ← Subscription plans + Stripe scaffold
├── home.py             ← Landing page route
├── requirements.txt    ← Python dependencies
├── .env.example        ← Environment variable template
├── tradersvault.db     ← SQLite database (auto-created)
│
├── templates/
│   ├── base.html       ← Navbar, flash messages, footer
│   ├── home.html       ← Landing page
│   ├── login.html      ← Login form
│   ├── register.html   ← Registration form
│   ├── journal.html    ← Trade journal (core feature)
│   ├── edit_trade.html ← Edit trade page
│   ├── analytics.html  ← Analytics dashboard + charts
│   ├── news.html       ← Market news feed
│   ├── plans.html      ← Pricing/subscription plans
│   └── profile.html    ← User profile
│
└── static/
    ├── css/style.css   ← Full dark fintech stylesheet
    ├── js/main.js      ← Modals, nav, RR calculator, UX
    └── uploads/        ← User chart image uploads
```

---

## 🚀 Quick Start

### 1. Clone or download the project

```bash
cd tradersvault
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# macOS / Linux:
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up environment variables

```bash
cp .env.example .env
# Edit .env with your values
```

### 5. Run the application

```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## 🔑 Features

### ✅ Trading Journal
- Log trades: pair, direction (buy/sell), entry, SL, TP, P&L, session, notes
- Auto risk-to-reward calculation
- Upload chart screenshots
- Edit and delete trades
- Import trades from CSV
- Export trades to CSV
- Searchable trade history table

### ✅ Analytics Dashboard
- Filter by: Daily / Weekly / Monthly / Yearly / All Time
- Metrics: total trades, win rate, avg R:R, total P&L
- Best and worst performing pairs
- Best trading session (Asian / London / New York)
- Charts: Monthly P&L bar chart, Win/Loss donut, Buy vs Sell split
- Pair performance table
- Session performance table

### ✅ Market News
- Live RSS feeds from financial news sources
- Category filtering: Forex, Crypto, Stocks, Commodities, Macro
- Fallback static news if feeds are unavailable

### ✅ Subscription Plans
- 3 tiers: Starter ($9.99), Pro ($24.99), Elite ($59.99)
- Stripe checkout scaffold ready to activate
- Webhook handler stub included
- FAQ section

### ✅ Authentication
- User registration with password hashing (Werkzeug)
- Session-based login/logout
- Login-required decorator on all protected routes

---

## 💳 Enabling Stripe Payments

1. Create a [Stripe account](https://stripe.com) and get your API keys
2. Add keys to your `.env` file:
   ```
   STRIPE_PUBLIC_KEY=pk_live_...
   STRIPE_SECRET_KEY=sk_live_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```
3. Create your products and prices in the Stripe Dashboard
4. Update `PLANS` in `plans.py` with your real `price_id` values
5. Install the Stripe library:
   ```bash
   pip install stripe
   ```
6. Uncomment the Stripe code in `plans.py` `checkout()` and `stripe_webhook()` functions

---

## 🌐 Deploying to a Live Domain

### Option A: Railway (Recommended for beginners)
1. Push to GitHub
2. Connect repo to [railway.app](https://railway.app)
3. Add environment variables in the Railway dashboard
4. Set `SITE_DOMAIN` to your Railway URL or custom domain

### Option B: VPS (Ubuntu / Nginx + Gunicorn)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```
Configure Nginx to proxy to port 8000.

### Option C: Render / Fly.io / Heroku
Set the start command to:
```
gunicorn app:app
```
And add all environment variables from `.env.example`.

### Setting your domain
In `.env`:
```
SITE_DOMAIN=https://yourdomain.com
```
In `app.py` this is already wired into `app.config['SITE_DOMAIN']`.

---

## 📰 Live News API (Optional Upgrade)

The default news page uses free RSS feeds. For production, upgrade to:

**NewsAPI** (newsapi.org):
```python
# In news.py, replace fetch_rss_feed with:
import requests
url = f"https://newsapi.org/v2/everything?q=forex&apiKey={API_KEY}"
```

**Finnhub** (finnhub.io):
```python
url = f"https://finnhub.io/api/v1/news?category=forex&token={API_KEY}"
```

---

## 🤖 Adding AI Trade Analysis

For the Elite plan AI analysis feature, integrate the Anthropic API:

```bash
pip install anthropic
```

```python
import anthropic

client = anthropic.Anthropic(api_key="YOUR_ANTHROPIC_KEY")

def analyze_trade(trade_data):
    message = client.messages.create(
        model="claude-opus-4-20250514",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": f"Analyze this trade and give improvement suggestions: {trade_data}"
        }]
    )
    return message.content[0].text
```

Add a route in `journal.py` and call this from the journal page for Elite users.

---

## 🔧 Configuration Reference

| Variable | Description | Default |
|---|---|---|
| `SECRET_KEY` | Flask session secret | `traders-vault-dev-...` |
| `SITE_DOMAIN` | Your domain URL | `http://localhost:5000` |
| `SITE_EMAIL` | Support email | `support@tradersvault.com` |
| `STRIPE_PUBLIC_KEY` | Stripe publishable key | — |
| `STRIPE_SECRET_KEY` | Stripe secret key | — |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook secret | — |
| `PORT` | Server port | `5000` |
| `FLASK_ENV` | `development` or `production` | `development` |

---

## 📋 CSV Import Format

When importing trades, use this column order:

```
pair,direction,entry_price,stop_loss,take_profit,rr_ratio,profit_loss,session,notes,trade_date
EURUSD,Buy,1.08420,1.07900,1.09500,2.1,180.00,London,Good momentum setup,2025-01-15
GBPUSD,Sell,1.26500,1.27100,1.25000,2.5,-95.00,New York,Stop hunt entry,2025-01-16
```

---

## ⚠️ Legal Notice

This platform is for educational and journaling purposes.  
Trading involves significant risk of loss. Nothing on this platform constitutes financial advice.
