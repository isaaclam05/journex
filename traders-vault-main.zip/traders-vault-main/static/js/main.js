/* Traders Vault — Main JS */

function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open'); document.body.style.overflow = '';
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      m.classList.remove('open'); document.body.style.overflow = '';
    });
  }
});

// Mobile sidebar
const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
if (menuBtn && sidebar && overlay) {
  menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
  });
}

// Show mobile menu btn on small screens
function checkMobile() {
  if (menuBtn) menuBtn.style.display = window.innerWidth <= 1024 ? 'flex' : 'none';
}
window.addEventListener('resize', checkMobile);
checkMobile();

document.addEventListener('DOMContentLoaded', () => {
  // Auto dismiss flashes after 5s
  setTimeout(() => {
    document.querySelectorAll('.flash').forEach(f => {
      f.style.transition = 'opacity .4s, transform .4s';
      f.style.opacity = '0'; f.style.transform = 'translateX(110%)';
      setTimeout(() => f.remove(), 400);
    });
  }, 5000);

  // Default date inputs to today
  document.querySelectorAll('input[type="date"]').forEach(i => {
    if (!i.value) i.value = new Date().toISOString().split('T')[0];
  });

  // Auto R:R calculator
  const entry = document.querySelector('[name="entry_price"]');
  const sl    = document.querySelector('[name="stop_loss"]');
  const tp    = document.querySelector('[name="take_profit"]');
  const dir   = document.querySelector('[name="direction"]');
  function calcRR() {
    if (!entry || !sl || !tp || !dir) return;
    const e = parseFloat(entry.value), s = parseFloat(sl.value), t = parseFloat(tp.value), d = dir.value;
    if (isNaN(e)||isNaN(s)||isNaN(t)) return;
    const risk = d==='Buy' ? e-s : s-e;
    const rew  = d==='Buy' ? t-e : e-t;
    if (risk>0) {
      let el = document.getElementById('rrCalc');
      if (!el) {
        el = document.createElement('div');
        el.id = 'rrCalc';
        el.style.cssText = 'margin-top:5px;padding:5px 10px;background:var(--blue-dim);border:1px solid var(--border-hi);border-radius:6px;font-size:11.5px;color:var(--blue-2);font-family:var(--font-mono);';
        tp.parentElement.appendChild(el);
      }
      el.textContent = `R:R → ${(rew/risk).toFixed(2)}:1`;
    }
  }
  [entry,sl,tp,dir].forEach(el => {
    if(el) { el.addEventListener('input',calcRR); el.addEventListener('change',calcRR); }
  });

  // Animate cards
  if ('IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.style.animation = 'fadeUp 0.3s ease forwards';
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.05 });
    document.querySelectorAll('.feature-card,.plan-card,.news-card,.metric-card,.stat-card').forEach(el => {
      el.style.opacity = '0'; obs.observe(el);
    });
  }
});

const s = document.createElement('style');
s.textContent = `@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}} @keyframes pulse{0%,100%{opacity:1;transform:scale(1);}50%{opacity:.4;transform:scale(.7);}} @keyframes tickerScroll{from{transform:translateX(0);}to{transform:translateX(-50%);}}`;
document.head.appendChild(s);
